node.default['icrt-installPrometheus']['user']='icrt-user'
node.default['icrt-installPrometheus']['group']='icrt-user'

node.default['icrt-installPrometheus']['activeVOSMnt'] = '/var/activevos'
node.default['icrt-installPrometheus']['PrometheusInstallDir'] = "#{node.default['icrt-installPrometheus']['activeVOSMnt']}"+'/prometheus'
node.default['icrt-installPrometheus']['PrometheusJar'] = "#{ node.default['icrt-installPrometheus']['activeVOSMnt'] }"+"/prometheus/jmx_prometheus_httpserver.jar"
node.default['icrt-installPrometheus']['PrometheusYaml'] = "#{ node.default['icrt-installPrometheus']['activeVOSMnt'] }"+"/prometheus/icrt-e.yaml"
node.default['icrt-installPrometheus']['PrometheusLogDir'] = '/var/log/prometheus'
node.default['icrt-installPrometheus']['PrometheusService'] = '/etc/init.d/prometheus'