#
# Cookbook Name:: icrt-installPrometheus
# Recipe:: default
#
# Copyright 2017, Informatica
#
# All rights reserved - Do Not Redistribute
#

# Nothing needs to be done to this cookbook

promUser = node['icrt-installPrometheus']['user']
promGroup = node['icrt-installPrometheus']['group']
promServiceScript = node['icrt-installPrometheus']['PrometheusService']

directory node['icrt-installPrometheus']['PrometheusInstallDir'] do
	mode	"0755"
    owner   promUser
    group   promGroup
end

directory node['icrt-installPrometheus']['PrometheusLogDir'] do
	mode	"0755"
    owner   promUser
    group   promGroup
end

cookbook_file node['icrt-installPrometheus']['PrometheusJar'] do
	source	"jmx_prometheus_httpserver.jar"
	mode	"0755"
    owner   promUser
    group   promGroup
end

cookbook_file node['icrt-installPrometheus']['PrometheusYaml'] do
	source	"icrt-e.yaml"
	mode	"0755"
    owner   promUser
    group   promGroup
end

cookbook_file promServiceScript do
	source	"prometheus"
	mode	"0755"
    owner   promUser
    group   promGroup
end

service	"prometheus" do
	init_command	promServiceScript
	start_command	"#{promServiceScript} start"
	restart_command	"#{promServiceScript} restart"
	stop_command	"#{promServiceScript} stop"
	action	[:start, :enable, :restart]
end