#
# Cookbook Name:: icrt-configureSumologic
# Recipe:: default
#
# Copyright 2017, Informatica
#
# All rights reserved - Do Not Redistribute
#

sumoUser = node['icrt-configureSumologic']['user']
sumoGroup = node['icrt-configureSumologic']['group']
sumoService = node['icrt-configureSumologic']['service']
sumoSite = node['icrt-configureSumologic']['site']
hostname = node['hostname']

cookbook_file '/opt/SumoCollector/config/collector.properties' do
	source  'collector.properties'
	action  :create
	mode    "0755"
	owner   sumoUser
	group   sumoGroup
end

# collectorName sample: IICS_Installed_PR_taskflowapp101s
collectorName = "#{sumoService}_Installed_#{sumoSite}_#{hostname}"

template '/opt/SumoCollector/config/user.properties' do
	source  'user.properties.erb'
	variables ({
		:collectorName	=> collectorName,
		:accessId		=> node['icrt-configureSumologic']['accessId'],
		:accessKey		=> node['icrt-configureSumologic']['accessKey']
	})
	action  :create
	mode    "0755"
    owner   sumoUser
    group   sumoGroup
end

# logName sample: IICS_PR_taskflowapp101s_tomcat_accesslog
logName = "#{sumoService}_#{sumoSite}_#{hostname}"

# sourceCategory sample: Prod_ICRT_App_Tomcat_Access
category =  "#{node['icrt-configureSumologic']['environment']}_#{sumoService}_#{node['icrt-configureSumologic']['application']}"

template '/opt/SumoCollector/config/sources.json' do
	source  'sources_haproxy.json.erb'
	variables ({
		:logName		=> logName,
		:sourceCategory	=> category
	})
	action  :create
	mode    "0755"
    owner   sumoUser
    group   sumoGroup
end

service "collector" do
	action [:enable, :start]
end