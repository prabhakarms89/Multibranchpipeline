resource_name :newman


property :postman_collection, String, default: ''
property :postman_environment, String, default: ''
property :ssl_client_cert, String, default: ''
property :ssl_client_key, String, default: ''
property :ssl_client_passphrase, String, default: ''


def remote_url
  "https://rpm.nodesource.com/setup_7.x"
end

action :install do
  execute "nodejs_install_rpm" do
    command "curl --silent --location #{remote_url} | bash -"
  end

  yum_package "nodejs"

  execute "newman_install" do
    command "npm install newman -g"
  end
end

 #TODO: add SSL checks
action :run do
  execute "newman_run" do
    command "newman run #{postman_collection} -e #{postman_environment} --reporter-cli-no-summary --insecure --ssl-client-cert #{ssl_client_cert} --ssl-client-key #{ssl_client_key} --ssl-client-passphrase #{ssl_client_passphrase}"
    live_stream true
  end
end

action :remove do
  execute "newman_uninstall" do
    command "npm uninstall newman -g"
  end

  yum_package "nodejs" do
    action :remove
  end
end
