#
# Cookbook:: build_cookbook
# Recipe:: syntax
#
# Copyright:: 2017, Informatica LLC, All Rights Reserved.
include_recipe 'delivery-truck::syntax'
