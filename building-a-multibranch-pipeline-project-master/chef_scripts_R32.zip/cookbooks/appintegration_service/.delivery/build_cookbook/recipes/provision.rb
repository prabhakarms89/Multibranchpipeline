#
# Cookbook:: build_cookbook
# Recipe:: provision
#
# Copyright:: 2017, Informatica LLC, All Rights Reserved.
include_recipe 'delivery-truck::provision'
