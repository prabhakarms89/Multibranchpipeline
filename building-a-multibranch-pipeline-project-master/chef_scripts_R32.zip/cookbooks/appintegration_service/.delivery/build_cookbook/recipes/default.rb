#
# Cookbook:: build_cookbook
# Recipe:: default
#
# Copyright:: 2017, Informatica LLC, All Rights Reserved.
include_recipe 'delivery-truck::default'
