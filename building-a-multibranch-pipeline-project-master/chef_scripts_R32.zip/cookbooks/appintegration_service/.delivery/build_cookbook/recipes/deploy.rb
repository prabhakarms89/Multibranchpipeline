#
# Cookbook:: build_cookbook
# Recipe:: deploy
#
# Copyright:: 2017, Informatica LLC, All Rights Reserved.
include_recipe 'delivery-truck::deploy'
