#
# Copyright:: 2017, Informatica LLC, All Rights Reserved.
#
# Generates a truststore for use by services. 
# Currently this script creates a truststore allows the service to connect to other 
# IICS services and AWS RDS instance over SSL.
#

#disable debugging to prevent passwords from appearing in console, logs, etc.
set +x

usage()
{
    echo "usage: import-custom-ca-cert.sh -b bundlefile -bpf bundlePassowrdFile -w workdir -ts truststore -tpf truststorePasswordFile"
	echo "        bundlefile: The CA cert bundle file containing all the certificates required to be imported"
	echo "        bundlePassowrdFile: File to read the bundle Password from"
	echo "        workdir: An existing folder location that this script can use as scratch folder"
	echo "        truststore: Path to the Java truststore (JKS file) into which the CA certs must be imported"
	echo "        truststorePasswordFile: File to read the truststore Password from"
}

while [ "$1" != "" ]; do
    case $1 in
        -b ) 	shift
				bundle=$1
				;;
		-bpf ) 	shift
				bundlepassfile=$1
				;;		
        -w )    shift
				workDir=$1
				;;
        -ts )   shift
				truststore=$1
				;;
        -tpf )   shift
				tspassfile=$1
				;;
        * )		usage
                exit 1
    esac
    shift
done

echo "[INFO] bundle:$bundle, bundlePassowrdFile:$bundlepassfile, workDir:$workDir, truststore:$truststore, truststorePasswordFile: $tspassfile"
if [[ -z "$bundle" || -z "$bundlepassfile" || -z "$workDir" || -z "$truststore" || -z "$tspassfile" ]]
then
      echo "[ERROR] Required parameters not specified. bundle:$bundle, bundlePassowrdFile:$bundlepassfile, workDir:$workDir, truststore:$truststore, truststorePasswordFile: $tspassfile"
	  usage
	  exit 1;
fi

if [ ! -f $bundlepassfile ]; then
    echo "[ERROR] Bundle password file specified does not exist or is not accessible: $bundlepassfile"
	exit 1;
fi

if [ ! -f $tspassfile ]; then
    echo "[ERROR] Trustore password file specified does not exist or is not accessible: $tspassfile"
	exit 1;
fi

bundlepass=$(cat $bundlepassfile)

#read password from file into memory.
tspass=$(cat $tspassfile)

# Merge the bundle with truststore 
echo "======= Import CA certs into truststore"
# import the cert into the default java keystore
keytool -importkeystore -srckeystore $bundle -destkeystore $truststore -srcstorepass $bundlepass -deststorepass $tspass -noprompt
