#
# Copyright:: 2017, Informatica LLC, All Rights Reserved.
#
# Generates a truststore for use by services. 
# Currently this script creates a truststore allows the service to connect to other 
# IICS services and AWS RDS instance over SSL.
#

#disable debugging to prevent passwords from appearing in console, logs, etc.
set +x

usage()
{
    echo "usage: import-rds-combined-cert.sh -b bundlefile -w workdir -ts truststore -tpf truststorePasswordFile"
	echo "        bundlefile: The CA cert bundle file such as the one downloaded from https://s3.amazonaws.com/rds-downloads/rds-combined-ca-bundle.pem"
	echo "        workdir: An existing folder location that this script can use as scratch folder"
	echo "        truststore: Path to the Java truststore (JKS file) into which the CA certs must be imported"
	echo "        truststorePasswordFile: File to read the truststore Password from"
}

while [ "$1" != "" ]; do
    case $1 in
        -b ) 	shift
				bundle=$1
				;;
        -w )    shift
				workDir=$1
				;;
        -ts )   shift
				truststore=$1
				;;
        -tpf )   shift
				tspassfile=$1
				;;
        * )		usage
                exit 1
    esac
    shift
done

echo "[INFO] bundle:$bundle, workDir:$workDir, truststore:$truststore, truststorePasswordFile: $tspassfile"
if [[ -z "$bundle" || -z "$workDir" || -z "$truststore" || -z "$tspassfile" ]]
then
      echo "[ERROR] Required parameters not specified. bundle:$bundle, workDir:$workDir, truststore:$truststore, truststorePasswordFile: $tspassfile"
	  usage
	  exit 1;
fi
if [ ! -f $tspassfile ]; then
    echo "[ERROR] Trustore password file specified does not exist or is not accessible: $tspassfile"
	exit 1;
fi


#read password from file into memory.
tspass=$(cat $tspassfile)

# log any rds certs prior to import
echo "======= Trusted Certs Before Import: Start"
keytool -list \
    -keystore $truststore \
    -storepass $tspass -noprompt \
	| grep -i rds
echo "======= Trusted Certs Before Import: End"

# split the bundle into individual certs (prefixed with xx)
echo "======= Splitting CA bundle into individual files..."
csplit -sz $bundle '/-BEGIN CERTIFICATE-/' '{*}'

# import each cert individually
echo "======= Import CA certs into truststore"
for CERT in xx*; do
    # extract a human-readable alias from the cert
    ALIAS=$(openssl x509 -noout -text -in $CERT |
        perl -ne 'next unless /Subject:/; s/.*CN=//; print')
    echo "importing $ALIAS"
    # import the cert into the default java keystore
    keytool -import \
        -keystore $truststore \
        -storepass $tspass -noprompt \
        -alias "$ALIAS" -file $CERT
done

# log the imported rds certs
echo "======= Trusted Certs After Import: Start"
keytool -list \
    -keystore $truststore \
    -storepass $tspass -noprompt \
	| grep -i rds | tee $workDir/verify.txt 
echo "======= Trusted Certs After Import: End"

# verify that trust store has AWS RDS CA certs. If not fail the script.
echo "======= Verifying that the truststore now includes the RDS CA certs"
if [[ $(wc -l < $workDir/verify.txt) -eq 0 ]] 
then
	echo "[ERROR] The truststore does not have RDS CA Certs as expected."
	exit 1;
fi

echo "======= Verified that the truststore includes the RDS CA certs."
