#
# Copyright:: 2017, Informatica LLC, All Rights Reserved.
#
# Generates a keystore that does not have any keys in it.
# It is currently used to override/replace the globally specified JVM keystore (-Djavax.net.ssl.keyStore)
# in the context of JDBC url (clientCertificateKeyStoreUrl parameter).
#

#disable debugging to prevent passwords from appearing in console, logs, etc.
set +x

usage()
{
    echo "usage: generate-mysql-disable-client-cert-emptystore.sh -w workdir -ks keystore -kpf keystorePasswordFile"
	echo "        workdir: An existing folder location that this script can use as scratch folder"
	echo "        keystore: Path to the Java keystore (JKS file) where the empty keystore needs to be generated"
	echo "        keystorePasswordFile: File to read the keystore password"
}

while [ "$1" != "" ]; do
    case $1 in
        -w )    shift
				workDir=$1
				;;
        -ks )   shift
				keystore=$1
				;;
        -kpf )   shift
				kspassfile=$1
				;;
        * )		usage
                exit 1
    esac
    shift
done

echo "[INFO] workDir:$workDir, keystore:$keystore, keystorePasswordFile: $kspassfile"
if [[ -z "$workDir" || -z "$keystore" || -z "$kspassfile" ]]
then
      echo "[ERROR] Required parameters not specified. workDir:$workDir, keystore:$keystore, keystorePasswordFile: $kspassfile"
	  usage
	  exit 1;
fi
if [ ! -f $kspassfile ]; then
    echo "[ERROR] Keystore password file specified does not exist or is not accessible: $kspassfile"
	exit 1;
fi


#read password from file into memory.
kspass=$(cat $kspassfile)

tempEmptyKeyStore=$workDir/tempempty.jks

if [ -f $tempEmptyKeyStore ]; then
	rm $tempEmptyKeyStore
fi

echo "======= Create keystore with dummy key which will soon be deleted."
keytool -genkey \
		-noprompt \
		-alias dummy \
		-dname "CN=dummy.appintegration.informaticacloud.com, OU=ID, O=Informatica, L=Informatica, S=Informatica, C=Informatica" \
		-keystore $tempEmptyKeyStore \
		-storepass $kspass \
		-keypass $kspass

echo "======= Now empty the keystore by deleting the dummy key that we just added."		
keytool -delete \
	-alias dummy  \
	-keystore $tempEmptyKeyStore \
	-storepass $kspass 

# verify that trust store has AWS RDS CA certs. If not fail the script.
echo "======= Verifying that the keystore is in fact empty"
keytool -list \
	-keystore $tempEmptyKeyStore \
	-storepass $kspass \
	| tee $workDir/emptykeystoreverify.txt

if grep -q "Your keystore contains 0 entries" "$workDir/emptykeystoreverify.txt";
then
	echo "[INFO] Verified empty keystore."
else
	echo "[ERROR] Error generating empty keystore. Keystore is not empty as expected. Contents:" 
	cat $workDir/emptykeystoreverify.txt
	exit 1;
fi

echo "[INFO] Placing the generated empty keystore at: " + $keystore
mv $tempEmptyKeyStore $keystore
chmod 755 $keystore
ls -l $keystore
