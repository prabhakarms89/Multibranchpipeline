#For DB Creation
#
default["appintegration_service"]["create_mysql_database_ddl"] = "create_schema.sql"
default["appintegration_service"]["activebpel_mysql_database_ddl"] = "ActiveBPEL_Enterprise-MySQL.sql"
default["appintegration_service"]["activebpel_create_mysql_repo_ddl"] = "create_repository_MySQL.ddl"
default["appintegration_service"]["insert_users_ddl"] = "insert_users.sql"
default["appintegration_service"]["account_ddl"] = "acct.ddl"
default["appintegration_service"]["AE_Process_Log_ddl"] = "AE_Process_Log_table.sql"
#
default["appintegration_service"]["initialize_database"] = "false"
default["appintegration_service"]["initialize_log_database"] = "false"
default["appintegration_service"]["enable_account_database"] = "false"
default["appintegration_service"]["update_database"] = "false"
#
default["appintegration_service"]["database_host"] = "localhost"
default["appintegration_service"]["database_root_user"] = "root"
default["appintegration_service"]["database_root_password"] = "root"
default["appintegration_service"]["log_database_host"] = "localhost"
default["appintegration_service"]["log_database_root_user"] = "root"
default["appintegration_service"]["log_database_root_password"] = "root"
default["appintegration_service"]["database_user"] = "activevos"
default["appintegration_service"]["database_password"] = "password"
default["appintegration_service"]["database_port"] = "3306"
default["appintegration_service"]["database_name"] = "activevos_db"
default["appintegration_service"]["log_database_user"] = "activevoslog"
default["appintegration_service"]["log_database_password"] = "password"
default["appintegration_service"]["log_database_port"] = "3306"
default["appintegration_service"]["log_database_name"] = "activevos_log"
default["appintegration_service"]["account_database_name"] = "activevos_acct"
default["appintegration_service"]["account_database_host"] = "localhost"
default["appintegration_service"]["account_database_root_user"] = "root"
default["appintegration_service"]["account_database_root_password"] = "root"
default["appintegration_service"]["account_database_user"] = "activevosacct"
default["appintegration_service"]["account_database_password"] = "activevos"
default["appintegration_service"]["account_database_port"] = "3306"
default["appintegration_service"]["icrt_cert_user"] = "CN=#{node["appintegration_service"]["runtime_host_name"]}, OU=Informatica Cloud Services, O=Informatica, L=Redwood City, ST=CA, C=US"
default["appintegration_service"]["internal_HA_cert_user"] = "CN=internal.ics.dev, OU=Informatica Cloud Services, O=Informatica, L=Redwood City, ST=CA, C=US"

#Update database
default["appintegration_service"]["ddls_deploy_path"] = "/opt/packages/ddls"
default["appintegration_service"]["ddl_update_directory_process"] = "updates/enterprise"
default["appintegration_service"]["ddl_update_directory_log"] = "updates/enterprise"
default["appintegration_service"]["ddl_update_directory_acct"] = "updates/enterprise"
default["appintegration_service"]["ddl_update_script"] = "update.ddl"
default["appintegration_service"]["ddl_update_directory_socrates"] = "updates/screenflow"

default["appintegration_service"]["process_db_patch"]=[]
default["appintegration_service"]["process_log_db_patch"]=[]
default["appintegration_service"]["account_db_patch"]=[]
default["appintegration_service"]["socrates_db_patch"]=[]

#
#db encrypted connection
# Specify whether the app needs to be configured to be able to talk to AWS RDS based database using SSL.
default["appintegration_service"]["database_setup_aws_rds_ssl"] = "false"
# configure whether services should use encrypted connection when connnecting to db (mysql)
default["appintegration_service"]["database_jdbc_use_ssl"] = "false"
# configure whether services should demand that db server support encrypted connection (mysql)
default["appintegration_service"]["database_jdbc_require_ssl"] = "false"
# We set java -Djavax.net.ssl.keyStore for the tomcat process to serve self-signed certs signed by infaca. This is done for 
# inter-microservice communication in IICS platform. But since infaca is NOT being added to the list of trusted certs in AWS RDS
# it breaks mysql jdbc connection. To prevent this self-signed client cert to be used in the context of jdbc connection we 
# need to point the jdbc url to a keystore doesn't have any private keys (a empty keystore file)
default["appintegration_service"]["database_jdbc_client_keystore_file"] = "/etc/ssl/infaca/mysql-disable-client-cert-emptystore.jks"
default["appintegration_service"]["database_jdbc_client_keystore_url"] = "file:#{node["appintegration_service"]["database_jdbc_client_keystore_file"]}"
# for simplicity we'll use the icrt_truststore's password for this emptystore also.
default["appintegration_service"]["database_jdbc_client_keystore_password"]= "#{node["appintegration_service"]["icrt_truststorePass"]}"
# the ca cert bundle .pem file containing ca certs that must trusted by the client in order to connect to ssl based server. 
# Example: /etc/ssl/infaca/rds-combined-ca-bundle.pem (downloaded from https://s3.amazonaws.com/rds-downloads/rds-combined-ca-bundle.pem)
default["appintegration_service"]["database_cacert"] = ""

## Start: Properties applicable only to environments that use AWS RDS based MySQL
# name of the AWS RDS CA Certificates bundle downloaded from https://s3.amazonaws.com/rds-downloads/rds-combined-ca-bundle.pem
default["appintegration_service"]["aws_rds_combined_ca_bundle"] = "rds-combined-ca-bundle.pem"
# Override the default temporary folder path used by the the import-rds-combined-cert.sh as workdir 
default["appintegration_service"]["import-rds-combined-cert-workdir"] = ""
## End: Properties applicable only to environments that use AWS RDS based MySQL
