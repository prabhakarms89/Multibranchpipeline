#
# environments
#
default["appintegration_service"]["platform"] = "qa"
default["appintegration_service"]["service_name"] = "appintegration_service"
if node['appintegration_service']['application_context'] == "AI"
	default["appintegration_service"]["service_name_prefix"] = "tomcat_ai"
	default["appintegration_service"]["tomcat_install_path"] = "/var/activevos/tomcat_ai"
elsif node['appintegration_service']['application_context'] == "DI" 
        default["appintegration_service"]["service_name_prefix"] = "tomcat_di"
	default["appintegration_service"]["tomcat_install_path"] = "/var/activevos/tomcat_di"
end

default["appintegration_service"]["active-bpel-health-war"] = "active-bpel-health.war"
default["appintegration_service"]["active-bpel-war"] = "active-bpel.war"
default["appintegration_service"]["activebpel-cert-war"] = "activebpel-cert.war"
default["appintegration_service"]["activevos-central-war"] = "activevos-central.war"
default["appintegration_service"]["activevos-war"] = "activevos.war"
default["appintegration_service"]["ce4sf-connectedapp-war"] = "ce4sf-connectedapp.war"
default["appintegration_service"]["oauthcallback-war"] = "oauthcallback.war"
default["appintegration_service"]["processdesigner-war"] = "processdesigner.war"
default["appintegration_service"]["processmonitor-war"] = "processmonitor.war"
default["appintegration_service"]["activevos-ai-war"] = "activevos-ai.war"
default["appintegration_service"]["version"] = "latest"
default["appintegration_service"]["artifact_store"] = "jenkins"
default["appintegration_service"]["shared_libs"] = "shared_tomcat_libs"
default["appintegration_service"]["shared_libs_packaging"] = "tar"
default["appintegration_service"]["shared_remote_file_name"] = "#{node["appintegration_service"]["shared_libs"]}.#{node["appintegration_service"]["shared_libs_packaging"]}"

default["appintegration_service"]["shutdown_wait"] = "20"
default["appintegration_service"]["restart_tomcat"] = true
default["appintegration_service"]["exclude_root"] = true
default["appintegration_service"]["exclude_manager"] = true
default["appintegration_service"]["exclude_examples"] = true
default["appintegration_service"]["exclude_docs"] = true
default["appintegration_service"]["exclude_root"] = true

#JAVA Version. Please change the JRE Home PATH Variable as well whenever the version is changed
default["appintegration_service"]["jre_version"] = "8u73-b02"
default["appintegration_service"]["jre_home_path"] = "/usr/java/jre1.8.0_73"

default["appintegration_service"]["xms_value"] = "-Xms256m"
default["appintegration_service"]["xmx_value"] = "-Xmx1024m"
default["appintegration_service"]["MetaspaceSize"] = "256m"
default["appintegration_service"]["MaxMetaspaceSize"] = "1280m"
default["appintegration_service"]["jmx_port"] = "7319"

if File.file?('/etc/profile.d/instancetags.sh')
if File.foreach('/etc/profile.d/instancetags.sh').grep(/TAG_AE_MACHINE_ID/).any?
default["appintegration_service"]["TAG_AE_Machine_ID"] = shell_out!('grep TAG_AE_MACHINE_ID /etc/profile.d/instancetags.sh | head -1 | cut -d"=" -f2 | tr -d "\n" | tr -d "\'" ').stdout
default["appintegration_service"]["AE_Machine_ID_Property"] = "-Dae.machine.id=" + "#{node["appintegration_service"]["TAG_AE_Machine_ID"]}"
else
default["appintegration_service"]["AE_Machine_ID_Property"] = "-Dae.machine.id=1"
end
else
default["appintegration_service"]["AE_Machine_ID_Property"] = "-Dae.machine.id=1"
end

#Default Catalina properties 
default["appintegration_service"]["default_catalina_opts"] = "-Djavax.xml.transform.TransformerFactory=com.saxonica.config.ProfessionalTransformerFactory -XX:MetaspaceSize=#{node["appintegration_service"]["MetaspaceSize"]} -XX:MaxMetaspaceSize=#{node["appintegration_service"]["MaxMetaspaceSize"]}  -Dsun.net.client.defaultConnectTimeout=10000 -Dsun.net.client.defaultReadTimeout=10000 -Djava.awt.headless=true -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=#{node["appintegration_service"]["tomcat_install_path"]}/logs -XX:GCTimeRatio=19 -XX:+UseConcMarkSweepGC -XX:+UseParNewGC -XX:ParallelGCThreads=4 -XX:NewRatio=2 -Dcom.sun.management.jmxremote.port=#{node["appintegration_service"]["jmx_port"]} -Dcom.sun.management.jmxremote.authenticate=true -Dcom.sun.management.jmxremote.ssl=false -Dcom.sun.management.jmxremote.password.file=#{node["appintegration_service"]["tomcat_install_path"]}/conf/jmxremote.password -Dcom.sun.management.jmxremote.access.file=#{node["appintegration_service"]["tomcat_install_path"]}/conf/jmxremote.access -Dorg.apache.xerces.xni.parser.XMLParserConfiguration=org.apache.xerces.parsers.XIncludeParserConfiguration #{node["appintegration_service"]["AE_Machine_ID_Property"]}"
#User specified Catalina opts
default["appintegration_service"]["other_catalina_opts"] = ""

#Catalina Opts = default Catalina Opts + Other Java Opts
if node["appintegration_service"]["other_catalina_opts"] != ""
default["appintegration_service"]["catalina_opts"] = "#{node["appintegration_service"]["default_catalina_opts"]} #{node["appintegration_service"]["other_catalina_opts"]}"
else
default["appintegration_service"]["catalina_opts"] = "#{node["appintegration_service"]["default_catalina_opts"]}"
end

#Migration temp dir
default["appintegration_service"]["migration_tmpdir"] = "#{node["appintegration_service"]["tomcat_install_path"]}/temp"
#Java Opts
default["appintegration_service"]["default_java_opts"] = "-Dmigration.tmpdir=#{node["appintegration_service"]["migration_tmpdir"]}"
#User specified JAVA Opts
default["appintegration_service"]["other_java_opts"] = ""

#Java opts = default Java Opts + Other Java Opts
if node["appintegration_service"]["other_java_opts"] != ""
default["appintegration_service"]["java_opts"] = "#{node["appintegration_service"]["default_java_opts"]} #{node["appintegration_service"]["other_java_opts"]}"
else
default["appintegration_service"]["java_opts"] = "#{node["appintegration_service"]["default_java_opts"]}"
end


default["appintegration_service"]["additional_access_log_pattern"] = "%{USER_SESSION}c"
default["appintegration_service"]["infa_log_level"] = "INFO"


default["appintegration_service"]["base_url"] = "ftp://psv28aeserver/releases/bolt/server/florence_Artifacts_ML/lastSuccessfulBuild/"
default["appintegration_service"]["artifactory_auth_key"] = "AKCp5bBh9WHoRHb1D5htA6dGRAe8hUtfm4dt1dFVs8Ku1kmz9DQcTogaLAsSKHYukaHfZN7wf"
default["appintegration_service"]["war_dest_path"] = "#{node["appintegration_service"]["tomcat_install_path"]}/webapps"

# security-filter_properties
default["appintegration_service"]["authfilter_ids_service_url"] = "https://dev-ma.informaticacloud.com/appintegration_service"
default["appintegration_service"]["authfilter_session_service_url"] = "https://dev-ma.informaticacloud.com/session-service/session"
default["appintegration_service"]["authfilter_ma_service_url"] = "https://dev-ma.informaticacloud.com/ma-service/home"
default["appintegration_service"]["authfilter_httpclient_maxconnection"] = "30"
default["appintegration_service"]["ipfilter_trusted_ip_ranges"] = ""

#Templates location
default["appintegration_service"]["ddls_templates_path"] = "ddls"
default["appintegration_service"]["context_templates_path"] = "context_xmls"
default["appintegration_service"]["iics_dep_deploy_templates_path"] = "iics-dep"

#license service dependency collection
default["appintegration_service"]["iics_dep_deploy_path"] = "/opt/iics_deploy"
default["appintegration_service"]["iics_dep_collection"] = "ai_iics_dep.postman_collection"
default["appintegration_service"]["iics_dep_environment"] = "ai_iics_dep.postman_environment"

# SSL options
default["appintegration_service"]["sslEnabled"] = "true"
default["appintegration_service"]["sslClientAuth"] = "false"
default["appintegration_service"]["dbSslClientAuthSupported"] = "false"
default["appintegration_service"]["cacert"] = "/etc/ssl/infaca/ca-bundle.pem"
default["appintegration_service"]["cert-key"] = "/etc/ssl/infaca/host-key.pem"
default["appintegration_service"]["cert-bundle"] = "/etc/ssl/infaca/host-bundle.pem"
default["appintegration_service"]["cert"] = "/etc/ssl/infaca/host-key-bundle.pem"


#Post deploy cofigurations
default["appintegration_service"]["product_version"] = "v1"
default["appintegration_service"]["cloudshell_path"] = "/cloudshell/api/v1"
default["appintegration_service"]["product_registry_path"] = "/ProductRegistry"
default["appintegration_service"]["product_registry_set_order_path"] = "/ProductRegistry/ProductRegistry.SetOrder"

default["appintegration_service"]["admin_username"] = "aeadmin"
default["appintegration_service"]["admin_password"] = "aeadmin"

#frontend-properties
default["appintegration_service"]["ma_service_base_url"] = "https://dev-ma.informaticacloud.com"
default["appintegration_service"]["opsinsights_base_url"] = "https://dev-ma.informaticacloud.com"
default["appintegration_service"]["cloud_shell_base_url"] = "https://dev-ma.informaticacloud.com"

# Enable compression
default["appintegration_service"]["useCompression"] = "true"

default["appintegration_service"]["remove_unsecure_access"] = "true"
default["appintegration_service"]["keystore_alias"] = "icrt"

#Active-bpel Activevos xml configuration
default["appintegration_service"]["server_ds_avosdb1_maxActive"] = "100"
default["appintegration_service"]["server_ds_avosdb1_maxIdle"] = "10"
default["appintegration_service"]["server_ds_avosdb1_maxWait"] = "5000"
default["appintegration_service"]["connectionTimeout_unsecure"] = "20000"
default["appintegration_service"]["maxThreads_tomcat_unsecure"] = "30"
default["appintegration_service"]["runtime_host_unsecure_port"] = "8080"
default["appintegration_service"]["runtime_host_secure_port"] = "8443"
default["appintegration_service"]["tomcat_max_threads"] = "600"
default["appintegration_service"]["tomcat_minSpareThreads"] = "4"
default["appintegration_service"]["icrt_keystoreFile"] = "/etc/ssl/infaca/icrt-keystore.jks"
default["appintegration_service"]["icrt_keystorePass"] = "changeit"

if node['domain'] == nil
   default["appintegration_service"]["runtime_host_name"] = "#{node["hostname"]}"
   default["appintegration_service"]["jvm_route"] = "#{node["hostname"]}"
   default["appintegration_service"]["cluster_bind_addr"] = "#{node["hostname"]}"
else
   default["appintegration_service"]["runtime_host_name"] = "#{node["hostname"]}.#{node['domain']}"
   default["appintegration_service"]["jvm_route"] = "#{node["hostname"]}.#{node['domain']}"
   default["appintegration_service"]["cluster_bind_addr"] = "#{node["hostname"]}.#{node['domain']}"
end

# Full path of the root-trustore.jks file that contains infaca certs prepared by IICS platform scripts
default["appintegration_service"]["root_truststoreFile"] = "/etc/ssl/infaca/root-truststore.jks" 
# Full path of icrt-truststore.jks file will be available for services to access. 
default["appintegration_service"]["icrt_truststoreFile"] = "/etc/ssl/infaca/icrt-truststore.jks" 
default["appintegration_service"]["icrt_truststorePass"] = "changeit"
default["appintegration_service"]["force_truststore_update"] = false 

default["appintegration_service"]["runtime_api_gateway_port"] = "9443"

#icrt_runtime_url is used in bpr deployment
default["appintegration_service"]["icrt_runtime_url"] = "http://localhost:8080"
default["appintegration_service"]["custom_ns"] = "icrt"

default["appintegration_service"]["cluster_enable"] = "false"
default["appintegration_service"]["cluster_bind_port"] = "9000"

default["appintegration_service"]["activebpel_ds_activevos_maxTotal"] = "300"
default["appintegration_service"]["activebpel_ds_activevos_maxIdle"] = "75"
default["appintegration_service"]["activebpel_ds_activevos_maxWaitMillis"] = "5000"
default["appintegration_service"]["activebpel_ds_log_activevos_maxTotal"] = "160"
default["appintegration_service"]["activebpel_ds_log_activevos_maxIdle"] = "50"
default["appintegration_service"]["activebpel_ds_log_activevos_maxWaitMillis"] = "240000"
default["appintegration_service"]["activevos_ds_activevos_maxTotal"] = "100"
default["appintegration_service"]["activevos_ds_activevos_maxIdle"] = "10"
default["appintegration_service"]["activevos_ds_activevos_maxWaitMillis"] = "5000"
default["appintegration_service"]["activevos_ai_maxIdle"] = "10"
default["appintegration_service"]["activevos_ai_maxTotal"] = "100"
default["appintegration_service"]["activevos_ai_maxWaitMillis"] = "1000"

#This activevos-cental web session timeout must be greater than cloud_shell_session_timeout
default["appintegration_service"]["session_timeout"] = "1860"
#cloushell config cloud session timeout
default["appintegration_service"]["cloud_shell_session_timeout"] = 1800

#Connectors
default["appintegration_service"]["connectors_path"] = "#{node["appintegration_service"]["tomcat_install_path"]}/../connectors"
default["appintegration_service"]["connectorUpdateZipRemote"] = "#{node["appintegration_service"]["base_url"]}/connectors.zip"

#configSettings.xml
default["appintegration_service"]["spi_url"] = "https://#{node["appintegration_service"]["runtime_host_name"]}:#{node["appintegration_service"]["runtime_host_secure_port"]}/active-bpel"
default["appintegration_service"]["urn_runtime_url"] = "https://#{node["appintegration_service"]["runtime_host_name"]}:#{node["appintegration_service"]["runtime_host_secure_port"]}"
default["appintegration_service"]["urn_business_event_stream_name"] = "cai_process_stream"
default["appintegration_service"]["obm_message_url"] = ""
default["appintegration_service"]["odata_endpoint_url"] = ""
default["appintegration_service"]["apigateway_key"] = ""
default["appintegration_service"]["ics_server"] =  "#{node["appintegration_service"]["ma_pod_url"]}"
default["appintegration_service"]["ics_user"] = ""
default["appintegration_service"]["ics_password"] = ""
default["appintegration_service"]["web_service_timeout"] = "100"

default["appintegration_service"]["whitelisted_connectors"] = "<connectorGUID>33ec8fc7-dc6d-4d2e-9f6f-a950669a62d1</connectorGUID>\n"

#Only for reinstalling the application
default["appintegration_service"]["app_reinstall"] = false
default["appintegration_service"]["tomcat_stop_waittimeout_sec"] = "30"

# Attributes related to prometheus jmx_exporter
default["appintegration_service"]["prometheus-jmx-exporter"]["dir"] = "#{node["appintegration_service"]["tomcat_install_path"]}/bin/prometheus_jmx_exporter"
default["appintegration_service"]["prometheus-jmx-exporter"]["jar"] = "jmx_prometheus_javaagent-0.3.2-SNAPSHOT.jar"
default["appintegration_service"]["prometheus-jmx-exporter"]["config_file"] = "jmx_exporter.yaml"