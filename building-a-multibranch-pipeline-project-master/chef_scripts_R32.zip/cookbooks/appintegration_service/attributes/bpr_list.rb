#BPR deployment
default["appintegration_service"]["bpr_install_path"] = "/opt/packages/bprs"
default["appintegration_service"]["bpr_deploy_path"] = "#{node.default["appintegration_service"]["bpr_install_path"]}/deploy/activevos/bprs"

#bolt Bprs list
default["appintegration_service"]["bolt_bprs"]=['com.activee.rt.hub.process.designer.sso.bpr', 'com.activee.rt.hub.process.designer.connector.services.bpr', 'com.activee.rt.hub.ics.rest.services.bpr', 'com.activee.rt.hub.process.designer.bpr', 'com.activee.rt.hub.migration.services.bpr', 'com.activee.rt.hub.cairegistry.bpr']

#ce4sf bpr list
default["appintegration_service"]["ce4sf_bprs"]=['com.activevos.cumulus.cloud.extend.playbook.bpr', 'com.activevos.cumulus.cloud.extend.playbook.configuration.bpr', 'com.activevos.cumulus.cloud.extend.playbook.headless.bpr', 'demo.com.activevos.cumulus.cloud.extend.playbook.guides.bpr', 'com.activevos.cumulus.cloud.extend.playbook.salesguides.bpr', 'demo.com.activevos.cumulus.cloud.extend.guide.provisioner.bpr', 'com.activevos.cumulus.cloud.extend.playbook.resources.bpr', 'com.activevos.cumulus.cloud.extend.playbook.provisioning.bpr']

#Socrates bpr list
default["appintegration_service"]["socrates_bprs"]=['com.activevos.socrates.central.bpr', 'com.activevos.socrates.repository.services.bpr', 'com.activevos.socrates.screenflow.editor.bpr', 'com.activevos.socrates.screenflow.editor.taskflow.bpr', 'com.activevos.socrates.florence.ui.bpr', 'com.activevos.socrates.screenflow.services.bpr', 'com.activevos.socrates.themes.bpr', 'com.activevos.socrates.mobile.bpr', 'com.activevos.socrates.serviceconnector.bpr', 'com.activevos.socrates.serviceconnector.import.bpr', 'com.activevos.socrates.ipd.services-cloud.bpr', 'com.activevos.socrates.ht.services.bpr']

#Alert Service bpr
default["appintegration_service"]["alertservice_bprs"]=['SystemAlerts.bpr']

#API GAteway Management bpr
default["appintegration_service"]["apigatewaymgmt_bprs"]=['com.activee.rt.hub.apigateway.management.bpr']

#Apigee Integration bpr list
default["appintegration_service"]["apigee_bprs"]=['com.activee.rt.hub.apigee.service.bpr', 'com.activee.rt.hub.apigee.ui.bpr']
