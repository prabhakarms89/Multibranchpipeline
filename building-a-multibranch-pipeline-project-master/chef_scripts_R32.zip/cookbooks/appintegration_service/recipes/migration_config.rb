# Cookbook Name:: appintegration_service
# # Recipe:: migration_config
# #
# # Copyright (c) 2018 The Authors, All Rights Reserved.
#

template "#{node['appintegration_service']['tomcat_install_path']}/conf/migration.yaml" do
  source 'tomcat_conf/migration_yaml.erb'
  owner 'tomcat'
  group 'tomcat'
  mode 00744
  cookbook 'appintegration_service'
  variables ({
	   :consul_uri => node['appintegration_service']['consul_uri'],
	   :consul_token => node['appintegration_service']['consul_token'],
	   :cai_pod_url => node['appintegration_service']['cai_pod_url'],
	   :cai_pod_url_key => node['appintegration_service']['cai_pod_url_key'],
	   :cai_admin_username => node['appintegration_service']['cai_admin_username'],
	   :cai_admin_password => node['appintegration_service']['cai_admin_password'],
	   :cai_pod_name => node['appintegration_service']['cai_pod_name'],
	   :icrt_url_key => node['appintegration_service']['icrt_url_key'],
	   :icrt_url => node['appintegration_service']['icrt_url'],
	   :icrt_migration_username => node['appintegration_service']['icrt_migration_username'],
	   :icrt_migration_password => node['appintegration_service']['icrt_migration_password'],
	   :icrt_genomics_url => node['appintegration_service']['icrt_genomics_url'],
	   :icrt_genomics_url_key => node['appintegration_service']['icrt_genomics_url_key'],
	   :icrt_genomics_migration_username => node['appintegration_service']['icrt_genomics_migration_username'],
	   :icrt_genomics_migration_password => node['appintegration_service']['icrt_genomics_migration_password'],
	   :icrt_genomics_migration_offset => node['appintegration_service']['icrt_genomics_migration_offset'],
	   :check_guides => node['appintegration_service']['check_guides'],
	   :wait_timeout => node['appintegration_service']['wait_timeout'],
	   :quiesce_timeout => node['appintegration_service']['quiesce_timeout'],
	   :skip_consul => node['appintegration_service']['skip_consul']
	})
end