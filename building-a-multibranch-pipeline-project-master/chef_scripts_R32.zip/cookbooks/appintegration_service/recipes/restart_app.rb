# Cookbook Name:: appintegration_service
# # # Recipe:: restart_app
# # #
# # # Copyright (c) 2017 The Authors, All Rights Reserved.
#

tomcatPath = node['appintegration_service']['tomcat_install_path']
waitTimeout = node['appintegration_service']['tomcat_stop_waittimeout_sec']
stopwaitTimeout = "20"

include_recipe "appintegration_service::disable_health"

#Stopping tomcat process
if node['appintegration_service']['restart_tomcat']
   execute "Stopping #{node['appintegration_service']['service_name']}" do
   command "/etc/init.d/#{node['appintegration_service']['service_name_prefix']} stop"
   ignore_failure false
   live_stream true
  end
end

Chef::Log.info("Waiting for #{stopwaitTimeout}Sec to settle down the connections")
execute "wait for #{stopwaitTimeout} Sec" do
  command "sleep #{stopwaitTimeout}"
end

if node['appintegration_service']['restart_tomcat']
   execute "Starting #{node['appintegration_service']['service_name']}" do
        command "/etc/init.d/#{node['appintegration_service']['service_name_prefix']} start"
        ignore_failure false
        live_stream true
   end

   http_request "HEAD #{node['appintegration_service']['icrt_runtime_url']}/active-bpel-health/healthcheck" do
      url "#{node['appintegration_service']['icrt_runtime_url']}/active-bpel-health/healthcheck"
      retries 10
      retry_delay 20
      action :head
   end

end
