# Cookbook Name:: appintegration_service
# Recipe:: update_jre
#
# Copyright (c) 2016 The Authors, All Rights Reserved.

#Adding the backup recipe

tomcatPath = node['appintegration_service']['tomcat_install_path']
waitTimeout = node['appintegration_service']['tomcat_stop_waittimeout_sec']

include_recipe "appintegration_service::disable_health"

#Stopping tomcat process
execute "Stopping #{node['appintegration_service']['service_name']}" do
   command "/etc/init.d/#{node['appintegration_service']['service_name_prefix']} stop"
   ignore_failure false
   live_stream true
end

#JRE Install
if node[:platform_family].include?("rhel")
  include_recipe "icrt-javainstall::jre"
end

#Starting the service back
if node['appintegration_service']['restart_tomcat']
   execute "Starting #{node['appintegration_service']['service_name']}" do
        command "/etc/init.d/#{node['appintegration_service']['service_name_prefix']} start"
        ignore_failure false
        live_stream true
   end

   http_request "HEAD #{node['appintegration_service']['icrt_runtime_url']}/active-bpel-health/healthcheck" do
      url "#{node['appintegration_service']['icrt_runtime_url']}/active-bpel-health/healthcheck"
      retries 10
      retry_delay 20
      action :head
   end

end

