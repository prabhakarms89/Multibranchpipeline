#
# Cookbook Name:: appintegration_service
# Recipe:: jmx_exporter
#
# Copyright 2017, Informatica
#
# All rights reserved - Do Not Redistribute
#

directory node["appintegration_service"]["prometheus-jmx-exporter"]['dir'] do
    owner "tomcat"
    group "tomcat"
end

cookbook_file node["appintegration_service"]["prometheus-jmx-exporter"]['jar'] do
	source	"prometheus_jmx_exporter/#{node["appintegration_service"]["prometheus-jmx-exporter"]['jar']}"
	path    "#{node["appintegration_service"]["prometheus-jmx-exporter"]['dir']}/#{node["appintegration_service"]["prometheus-jmx-exporter"]['jar']}"
    owner "tomcat"
    group "tomcat"
end

cookbook_file node["appintegration_service"]["prometheus-jmx-exporter"]['config_file'] do
	source	"prometheus_jmx_exporter/#{node["appintegration_service"]["prometheus-jmx-exporter"]['config_file']}"
	path    "#{node["appintegration_service"]["prometheus-jmx-exporter"]['dir']}/#{node["appintegration_service"]["prometheus-jmx-exporter"]['config_file']}"
    owner "tomcat"
    group "tomcat"
end
