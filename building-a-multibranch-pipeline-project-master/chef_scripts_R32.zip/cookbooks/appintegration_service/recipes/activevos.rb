#
# Cookbook:: appintegration_service
# Recipe:: deploy_activevos
#
# Copyright:: 2017, Informatica LLC, All Rights Reserved.
#
#

#BPR List
bolt_bpr=node["appintegration_service"]["bolt_bprs"]
ce4sf_bpr=node["appintegration_service"]["ce4sf_bprs"]
socrates_bpr=node["appintegration_service"]["socrates_bprs"]
alertservice_bpr=node["appintegration_service"]["alertservice_bprs"]
apigatewaymgmt_bpr=node["appintegration_service"]["apigatewaymgmt_bprs"]
apigee_bpr=node["appintegration_service"]["apigee_bprs"]

installPath = node["appintegration_service"]["bpr_install_path"]

#installing zip and unzip packages
package 'zip'
package 'unzip'

# Downloading the Latest Bprs
deploy_bprs "Deploying bprs" do
  base_url node['appintegration_service']['base_url']
  artifactory_api_key node['appintegration_service']['artifactory_auth_key']
  action :install
end

# Updating the BPR
deploy_bprs "Extracting the bpr com.activevos.cumulus.cloud.extend.playbook.configuration.bpr" do
  bpr_type "ce4sf/"
  bpr_file "com.activevos.cumulus.cloud.extend.playbook.configuration.bpr"
  action :extract
end

ruby_block 'Update Bpr com.activevos.cumulus.cloud.extend.playbook.configuration.bpr' do
  block do
    FileEdit.file_edit("#{Chef::Config['file_cache_path']}/tmp/config/runtimeServer.xml", "<tns:server>localhost</tns:server>", "<tns:server>#{node["appintegration_service"]["runtime_host_name"]}</tns:server>")
    FileEdit.file_edit("#{Chef::Config['file_cache_path']}/tmp/config/runtimeServer.xml", "<tns:port>80</tns:port>", "<tns:port>#{node["appintegration_service"]["runtime_host_secure_port"]}</tns:port>")
    FileEdit.file_edit("#{Chef::Config['file_cache_path']}/tmp/config/runtimeServer.xml", "<tns:protocol>http</tns:protocol>", "<tns:protocol>https</tns:protocol>")
  end
  action :run
end

deploy_bprs "Re-packaging bpr com.activevos.cumulus.cloud.extend.playbook.configuration.bpr" do
  bpr_type "ce4sf/"
  bpr_file "com.activevos.cumulus.cloud.extend.playbook.configuration.bpr"
  action :package
end

deploy_bprs "Extracting the bpr com.activee.rt.hub.ics.rest.services.bpr" do
  bpr_type "bolt"
  bpr_file "com.activee.rt.hub.ics.rest.services.bpr"
  action :extract
end

ruby_block 'Update Bpr com.activee.rt.hub.ics.rest.services.bpr' do
  block do
    FileEdit.file_edit("#{Chef::Config['file_cache_path']}/tmp/config/whiteListedConnectors.xml", "<connectorGUID>33ec8fc7-dc6d-4d2e-9f6f-a950669a62d1</connectorGUID>", "#{node["appintegration_service"]["whitelisted_connectors"]}")
  end
  action :run
end

deploy_bprs "Re-packaging bpr com.activee.rt.hub.ics.rest.services.bpr " do
  bpr_type "bolt"
  bpr_file "com.activee.rt.hub.ics.rest.services.bpr"
  action :package
end

#Updating configSettings.xml
template "#{node["appintegration_service"]["bpr_install_path"]}/deploy/activevos/resources/configSettings.new.xml" do
  owner 'tomcat'
  group 'tomcat'
  mode '755'
  source 'configSettings.xml.erb'
  variables ({
       :spi_url => node['appintegration_service']['spi_url'],
	   :urn_runtime_url => node['appintegration_service']['urn_runtime_url'],
	   :urn_business_event_stream_name => node['appintegration_service']['urn_business_event_stream_name'],
       :obm_message_url => node['appintegration_service']['obm_message_url'],
       :odata_endpoint_url => node['appintegration_service']['odata_endpoint_url'],
       :apigateway_key => node['appintegration_service']['apigateway_key'],
       :ai_internal_ha_proxy_url => node['appintegration_service']['ai_internal_ha_proxy_url'],
       :ics_server => node['appintegration_service']['ics_server'],
       :ics_user => node['appintegration_service']['ics_user'],
       :ics_password => node['appintegration_service']['ics_password'],
       :tomcat_install_path => node['appintegration_service']['tomcat_install_path'],
       :runtime_host_name => node['appintegration_service']['runtime_host_name'],
       :runtime_host_secure_port => node['appintegration_service']['runtime_host_secure_port'],
	   :web_service_timeout => node['appintegration_service']['web_service_timeout'],
	   :ai_external_pod_url => node['appintegration_service']['ai_external_pod_url'],
	   :internal_ha_proxy_url => node['appintegration_service']['internal_ha_proxy_url'],
   	   :application_context => node['appintegration_service']['application_context']
      })
end

execute "set cli utility permission" do
  cwd "#{installPath}/deploy"
  command "chmod -R 755 cli"
end

cliDir = "#{installPath}/deploy/cli"
deployPath = node["appintegration_service"]["bpr_deploy_path"]
adminUser = node["appintegration_service"]["admin_username"]
adminPass = node["appintegration_service"]["admin_password"]
icrtUrl = node["appintegration_service"]["icrt_runtime_url"]

# Deploying the BPRs
#

{"socrates" => socrates_bpr, "ce4sf" => ce4sf_bpr, "bolt" => (bolt_bpr + alertservice_bpr + apigatewaymgmt_bpr + apigee_bpr) }.each do |bprPath, bprList|
  bprList.each do |curBpr|
    execute "Deploy #{bprPath} #{curBpr}" do
      cwd cliDir
      command "./cli.sh -c deploybpr -u #{adminUser} -p #{adminPass} -f #{deployPath}/#{bprPath}/#{curBpr} -s #{icrtUrl}/active-bpel/services/ActiveBpelDeployBPR"
      ignore_failure false
      live_stream true
	  sensitive true
    end      
  end
end

execute "Invoke URL" do
  cwd cliDir
  command "./cli.sh -c invoke -u #{adminUser} -p #{adminPass} -f #{installPath}/deploy/activevos/resources/configSettings.new.xml -s #{icrtUrl}/active-bpel/services/AeConfigManagement"
  ignore_failure false
  live_stream true
  sensitive true
end
