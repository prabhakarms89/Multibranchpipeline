# Cookbook Name:: appintegration_service
# # # Recipe:: reinstall_init
# # #
# # # Copyright (c) 2017 The Authors, All Rights Reserved.
#

if node['appintegration_service']['app_reinstall']

tomcatPath = node['appintegration_service']['tomcat_install_path']
waitTimeout = node['appintegration_service']['tomcat_stop_waittimeout_sec']

if (Dir.exist?"#{tomcatPath}")

directory "#{tomcatPath}/../backup" do
  action :create
end

include_recipe "appintegration_service::disable_health"

#Stopping tomcat process
if node['appintegration_service']['restart_tomcat']
   execute "Stopping #{node['appintegration_service']['service_name']}" do
   command "/etc/init.d/#{node['appintegration_service']['service_name_prefix']} stop"
   ignore_failure false
   live_stream true
  end
end

execute "Taking the backup" do
  cwd "#{tomcatPath}/../backup"
  command "mv #{tomcatPath} #{node['appintegration_service']['service_name_prefix']}_backup_`date +%Y-%m-%d_%H-%M`"
  live_stream true
end
end
end
