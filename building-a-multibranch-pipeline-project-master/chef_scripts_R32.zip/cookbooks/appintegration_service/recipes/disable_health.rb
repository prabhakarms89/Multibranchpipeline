# Cookbook Name:: appintegration_service
# # # Recipe:: disable_health
# # #
# # # Copyright (c) 2017 The Authors, All Rights Reserved.
#

stopwaitTimeout = "60"
tomcat_path = "#{node["appintegration_service"]["tomcat_install_path"]}"

http_request 'DisableHealthCheck' do
  action :get
  url "#{node['appintegration_service']['icrt_runtime_url']}/active-bpel-health/offline"
  headers({'AUTHORIZATION' => "Basic #{
    Base64.encode64("#{node['appintegration_service']['admin_username']}:#{node['appintegration_service']['admin_password']}")}"
  })
  only_if ("ps -fe | grep  'org.apache.catalina.startup.Bootstrap start' | grep #{tomcat_path} | grep -v grep")
end

execute "wait for #{stopwaitTimeout} Sec" do
  Chef::Log.info("Waiting for #{stopwaitTimeout}Sec to settle down the connections")
  command "sleep #{stopwaitTimeout}"
  only_if ("ps -fe | grep  'org.apache.catalina.startup.Bootstrap start' | grep #{tomcat_path} | grep -v grep")
end
