# Cookbook Name:: appintegration_service
# # # Recipe:: enable_health
# # #
# # # Copyright (c) 2017 The Authors, All Rights Reserved.
#

tomcatPath = node['appintegration_service']['tomcat_install_path']
waitTimeout = node['appintegration_service']['tomcat_stop_waittimeout_sec']
stopwaitTimeout = "30"

http_request 'EnableHealthCheck' do
  action :get
  url "#{node['appintegration_service']['icrt_runtime_url']}/active-bpel-health/online"
  headers({'AUTHORIZATION' => "Basic #{
    Base64.encode64("#{node['appintegration_service']['admin_username']}:#{node['appintegration_service']['admin_password']}")}"
  })
end
