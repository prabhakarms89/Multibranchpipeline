# Cookbook Name:: appintegration_service
# # Recipe:: update_war
# #
# # Copyright (c) 2017 The Authors, All Rights Reserved.

package 'zip'
package 'unzip'
package 'sed'

directory "#{Chef::Config['file_cache_path']}/war_tmp" do
  recursive true
  action :delete
  only_if {::Dir.exist?"#{Chef::Config['file_cache_path']}/war_tmp"}
end

directory "#{Chef::Config['file_cache_path']}/war_tmp" do
  action :create
end

execute "unzip war" do
  cwd "#{Chef::Config['file_cache_path']}/war_tmp"
  command "unzip #{node['appintegration_service']['tomcat_install_path']}/webapps/activevos-central.war"
end

ruby_block 'Update aeworkflow-config.xml' do
  block do
    FileEdit.file_edit("#{Chef::Config['file_cache_path']}/war_tmp/WEB-INF/aeworkflow-config.xml", "http://localhost:8080/active-bpel", "https://#{node["appintegration_service"]["runtime_host_name"]}:#{node["appintegration_service"]["runtime_host_secure_port"]}/active-bpel")
    FileEdit.file_edit("#{Chef::Config['file_cache_path']}/war_tmp/WEB-INF/aeworkflow-config.xml", "https://localhost:8443/activebpel-cert", "https://#{node["appintegration_service"]["runtime_host_name"]}:#{node["appintegration_service"]["runtime_host_secure_port"]}/activebpel-cert")
  end
  action :run
end

ruby_block 'Update /activevos-central/ai-core-config-init.js with external url' do
  block do
    if node['appintegration_service']['application_context'] == "DI" then 
		ai_core_config_url=node["appintegration_service"]["external_pod_url"]
	elsif node['appintegration_service']['application_context'] == "AI"
		ai_core_config_url=node["appintegration_service"]["ai_external_pod_url"]
	end
    FileEdit.file_edit("#{Chef::Config['file_cache_path']}/war_tmp/ai/ai-core-config-init.js", "https://ai-pod.ics.dev:488", "#{ai_core_config_url}")
  end
  action :run
  only_if {::File.exist?"#{Chef::Config['file_cache_path']}/war_tmp/ai/ai-core-config-init.js"}
end

directory "#{node['appintegration_service']['tomcat_install_path']}/webapps/activevos-central" do
  recursive true
  action :delete
  only_if {::Dir.exist?"#{node['appintegration_service']['tomcat_install_path']}/webapps/activevos-central"}
end

file "#{node['appintegration_service']['tomcat_install_path']}/webapps/activevos-central.war" do
  action :delete
  only_if {::File.exist?"#{node['appintegration_service']['tomcat_install_path']}/webapps/activevos-central.war"}
end

execute "zip " do
  cwd "#{Chef::Config['file_cache_path']}/war_tmp"
  command "zip -r #{node['appintegration_service']['tomcat_install_path']}/webapps/activevos-central.war ."
end

directory "#{Chef::Config['file_cache_path']}/war_tmp" do
        recursive true
        action :delete
        only_if {::Dir.exist?"#{Chef::Config['file_cache_path']}/war_tmp"}
end



# Update active-bpel.war

if node["appintegration_service"]["cluster_enable"] == "true"
directory "#{Chef::Config['file_cache_path']}/war_tmp" do
  action :create
end

execute "unzip war" do
  cwd "#{Chef::Config['file_cache_path']}/war_tmp"
  command "unzip #{node['appintegration_service']['tomcat_install_path']}/webapps/active-bpel.war"
end

bash 'update aeEngineConfig.xml' do
  cwd "#{Chef::Config['file_cache_path']}/war_tmp/WEB-INF/classes/"
  code <<-EOH
    sed -i 's/<entry name="Class" value="com.activee.rt.cluster.AeLocalHostCluster"\\/>/<entry name="Class" value="com.activee.rt.cluster.jgroups.AeTomcatJGroupsCluster"\\/> <entry name="ClusterName" value="ActiveBPEL"\\/> <entry name="ChannelProperties" value="TCP(bind_port=#{node["appintegration_service"]["cluster_bind_port"]};bind_addr=%BindAddress%):FRAG2(frag_size=60k):JDBC_PING(initialize_sql=;datasource_jndi_name=java:comp\\/env\\/jdbc\\/ActiveVOS):MERGE3:FD_ALL(timeout=15000):VERIFY_SUSPECT(timeout=15000):pbcast.NAKACK2(use_mcast_xmit=false):UNICAST2:pbcast.STABLE:pbcast.GMS(view_ack_collection_timeout=10000):pbcast.STATE_TRANSFER"\\/> <entry name="BindAddress" value="#{node["appintegration_service"]["cluster_bind_addr"]}"\\/>/g' aeEngineConfig.xml
    EOH
end

directory "#{node['appintegration_service']['tomcat_install_path']}/webapps/active-bpel" do
  recursive true
  action :delete
  only_if {::Dir.exist?"#{node['appintegration_service']['tomcat_install_path']}/webapps/active-bpel"}
end

file "#{node['appintegration_service']['tomcat_install_path']}/webapps/active-bpel.war" do
  action :delete
  only_if {::File.exist?"#{node['appintegration_service']['tomcat_install_path']}/webapps/active-bpel.war"}
end

execute "zip " do
  cwd "#{Chef::Config['file_cache_path']}/war_tmp"
  command "zip -r #{node['appintegration_service']['tomcat_install_path']}/webapps/active-bpel.war ."
end

directory "#{Chef::Config['file_cache_path']}/war_tmp" do
        recursive true
        action :delete
        only_if {::Dir.exist?"#{Chef::Config['file_cache_path']}/war_tmp"}
end
end

execute "#{node['appintegration_service']['tomcat_install_path']}" do
        command "chmod -R 755  #{node['appintegration_service']['tomcat_install_path']}"
    action :run
end

execute "#{node['appintegration_service']['tomcat_install_path']}" do
  	command "chown -R tomcat:tomcat #{node['appintegration_service']['tomcat_install_path']}"
    action :run
end

execute "#{node['appintegration_service']['tomcat_install_path']}" do
  	command "chmod 400  #{node['appintegration_service']['tomcat_install_path']}/conf/jmxremote.password"
    action :run
end
