# Cookbook Name:: appintegration_service
# Recipe:: db
#
# Copyright (c) 2017 The Authors, All Rights Reserved.

deploy_ddls  "#{node['appintegration_service']['service_name']} deploy ddls" do
    ddls_deploy_path node['appintegration_service']['ddls_deploy_path']
    base_url node['appintegration_service']['base_url']
    action :install
end

if node['appintegration_service']['initialize_database'] == "true"
 mysql_script "create activevos db" do
  file_name "create_activevos_schema.sql"
  createSqlErbTemplate "#{node['appintegration_service']['ddls_templates_path']}/#{node['appintegration_service']['create_mysql_database_ddl']}.erb"
  mysqlhost "#{node['appintegration_service']['database_host']}"
  mysqluser "#{node['appintegration_service']['database_root_user']}"
  mysqlpassword "#{node['appintegration_service']['database_root_password']}"
  sslEnabled "#{node['appintegration_service']['database_jdbc_require_ssl']}"
  sslClientAuth "false"
  ssl_ca "#{node['appintegration_service']['database_cacert']}"

  db_schema "#{node['appintegration_service']['database_name']}"
  spring_datasource_user "#{node['appintegration_service']['database_user']}"
  spring_datasource_password "#{node['appintegration_service']['database_password']}"
  action :run
 end

mysql_post_script "create activevos repository sql script" do
  file_location "#{node['appintegration_service']['ddls_deploy_path']}/ActiveBPEL_Enterprise-MySQL.sql"
  mysqlhost "#{node['appintegration_service']['database_host']}"
  mysqluser "#{node['appintegration_service']['database_user']}"
  mysqlpassword "#{node['appintegration_service']['database_password']}"
  mysqlschema "#{node['appintegration_service']['database_name']}"
  ssl_ca "#{node['appintegration_service']['database_cacert']}"
  action :run
end


mysql_post_script "create activevos repository sql script" do
  file_location "#{node['appintegration_service']['ddls_deploy_path']}/create_repository_MySQL.ddl"
  mysqlhost "#{node['appintegration_service']['database_host']}"
  mysqluser "#{node['appintegration_service']['database_user']}"
  mysqlpassword "#{node['appintegration_service']['database_password']}"
  mysqlschema "#{node['appintegration_service']['database_name']}"
  ssl_ca "#{node['appintegration_service']['database_cacert']}"
  action :run
end

end

#Create Log database
if node['appintegration_service']['initialize_log_database'] == "true"
   mysql_script "create activevos log db" do
   file_name "create_log_schema.sql"
   createSqlErbTemplate "#{node['appintegration_service']['ddls_templates_path']}/#{node['appintegration_service']['create_mysql_database_ddl']}.erb"
   mysqlhost "#{node['appintegration_service']['log_database_host']}"
   mysqluser "#{node['appintegration_service']['log_database_root_user']}"
   mysqlpassword "#{node['appintegration_service']['log_database_root_password']}"
   sslEnabled "#{node['appintegration_service']['database_jdbc_require_ssl']}"
   sslClientAuth "false"
   ssl_ca "#{node['appintegration_service']['database_cacert']}"

   db_schema "#{node['appintegration_service']['log_database_name']}"
   spring_datasource_user "#{node['appintegration_service']['log_database_user']}"
   spring_datasource_password "#{node['appintegration_service']['log_database_password']}"
   action :run
   end

mysql_post_script "Creates tables in MySQL for Process Log" do
  file_location "#{node['appintegration_service']['ddls_deploy_path']}/AE_Process_Log_table.sql"
  mysqlhost "#{node['appintegration_service']['log_database_host']}"
  mysqluser "#{node['appintegration_service']['log_database_user']}"
  mysqlpassword "#{node['appintegration_service']['log_database_password']}"
  mysqlschema "#{node['appintegration_service']['log_database_name']}"
  ssl_ca "#{node['appintegration_service']['database_cacert']}"
  action :run
end

end


#Run the user account script 
if node['appintegration_service']['enable_account_database'] == "true"

mysql_script "create db" do
  file_name "create_acct_db.sql"
  createSqlErbTemplate "#{node['appintegration_service']['ddls_templates_path']}/#{node['appintegration_service']['create_mysql_database_ddl']}.erb"
  mysqlhost "#{node['appintegration_service']['account_database_host']}"
  mysqluser "#{node['appintegration_service']['account_database_root_user']}"
  mysqlpassword "#{node['appintegration_service']['account_database_root_password']}"
  sslEnabled "#{node['appintegration_service']['database_jdbc_require_ssl']}"
  sslClientAuth "false"
  ssl_ca "#{node['appintegration_service']['database_cacert']}"

  db_schema "#{node['appintegration_service']['account_database_name']}"
  spring_datasource_user "#{node['appintegration_service']['account_database_user']}"
  spring_datasource_password "#{node['appintegration_service']['account_database_password']}"
  action :run
end



mysql_post_script "create activevos repository sql script" do
  file_location "#{node['appintegration_service']['ddls_deploy_path']}/acct.ddl"
  mysqlhost "#{node['appintegration_service']['account_database_host']}"
  mysqluser "#{node['appintegration_service']['account_database_user']}"
  mysqlpassword "#{node['appintegration_service']['account_database_password']}"
  mysqlschema "#{node['appintegration_service']['account_database_name']}"
  ssl_ca "#{node['appintegration_service']['database_cacert']}"
  action :run
end


template "#{Chef::Config['file_cache_path']}/#{node['appintegration_service']['insert_users_ddl']}" do
  source "#{node['appintegration_service']['ddls_templates_path']}/#{node['appintegration_service']['insert_users_ddl']}.erb"
  mode '0755'
  cookbook 'appintegration_service'
  variables ({
       :admin_username => node['appintegration_service']['admin_username'],
       :admin_password => node['appintegration_service']['admin_password'],
       :internal_HA_cert_user => node['appintegration_service']['internal_HA_cert_user'],
       :icrt_cert_user => node['appintegration_service']['icrt_cert_user'],
	   :runtime_host_name => node['appintegration_service']['runtime_host_name']
})
end

mysql_post_script "create activevos repository sql script" do
  file_location "#{Chef::Config['file_cache_path']}/#{node['appintegration_service']['insert_users_ddl']}"
  mysqlhost "#{node['appintegration_service']['account_database_host']}"
  mysqluser "#{node['appintegration_service']['account_database_user']}"
  mysqlpassword "#{node['appintegration_service']['account_database_password']}"
  mysqlschema "#{node['appintegration_service']['account_database_name']}"
  ssl_ca "#{node['appintegration_service']['database_cacert']}"
  action :run
end

end