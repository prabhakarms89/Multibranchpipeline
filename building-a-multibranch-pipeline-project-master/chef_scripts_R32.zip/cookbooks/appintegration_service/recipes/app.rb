
# Cookbook Name:: appintegration_service
# Recipe:: app
#
# Copyright (c) 2016 The Authors, All Rights Reserved.

#Adding the backup recipe
if node['appintegration_service']['app_reinstall']
	include_recipe "appintegration_service::reinstall_init"
end

#JRE Install
if node[:platform_family].include?("rhel")
  include_recipe "icrt-javainstall::jre"
end

serviceName = node['appintegration_service']['service_name']
tomcatPath = node['appintegration_service']['tomcat_install_path']
baseUrl = node['appintegration_service']['base_url']
artifactoryApiKey = node['appintegration_service']['artifactory_auth_key']
warPath = node['appintegration_service']['war_dest_path']

# Install tomcat using tomcat_install service
tomcat_install serviceName do
    service_name_prefix node['appintegration_service']['service_name_prefix']
    install_path tomcatPath
	shutdown_wait node['appintegration_service']['shutdown_wait']
end

# Getting war in provisioning part
# Deploy stays in this recipe
[
  node['appintegration_service']['active-bpel-health-war'],
  node['appintegration_service']['active-bpel-war'],
  node['appintegration_service']['activebpel-cert-war'],
  node['appintegration_service']['activevos-central-war'],
  node['appintegration_service']['activevos-war'],
  node['appintegration_service']['ce4sf-connectedapp-war'],
  node['appintegration_service']['oauthcallback-war'],
  node['appintegration_service']['processdesigner-war'],
  node['appintegration_service']['processmonitor-war']
].each do |curWar|
log " -- Fetching #{curWar} from #{baseUrl} "
    remote_file "#{warPath}/#{curWar}" do
      source "#{baseUrl}/#{curWar}"
      headers 'X-JFrog-Art-Api' => artifactoryApiKey
      owner "tomcat"
      group "tomcat"
      mode "0755"
    end

end

#deploying activevos-ai war Only if application_context is "AI"
if node['appintegration_service']['application_context'] == "AI"
    activevosAiWarName = node['appintegration_service']['activevos-ai-war']

    remote_file "#{warPath}/#{activevosAiWarName}" do
      source "#{baseUrl}/#{activevosAiWarName}"
      headers 'X-JFrog-Art-Api' => artifactoryApiKey
      owner "tomcat"
      group "tomcat"
      mode "0755"
    end
end

#Installing the dependencies
deploy_libs "#{serviceName} deploy shared_tomcat_libs" do
    install_path tomcatPath
    source_url "#{baseUrl}/#{node['appintegration_service']['shared_remote_file_name']}"
    artifactory_api_key artifactoryApiKey
end

#Load the Static files from cookbook files 

['context.xml', 'jmxremote.access', 'jmxremote.password', 'logging.properties', 'catalina.policy', 'log4j2.xml'].each do |curFile|
  cookbook_file "#{tomcatPath}/conf/#{curFile}" do
    backup false
    owner 'tomcat'
    group 'tomcat'
    mode '0644'
  end
end

#Update the war
include_recipe "appintegration_service::update_war"
