# Cookbook Name:: appintegration_service
# Recipe:: truststore_setup
# 
# Set of steps to setup the java truststore as required by icrt services.
# The overall process of doing this is:
#	(1) Start with root_truststore file that contains infaca and other CA certs as setup by base IICS platform
#	(2) Add AWS RDS CA and Customer CA certs to that truststore.
#	(3) Rename the truststore to icrt_truststore and use it to replace the root_truststore that we started with.
# 	 
# The AWS RDS CA certs have been download from https://s3.amazonaws.com/rds-downloads/rds-combined-ca-bundle.pem
# and placed in cookbook "files" folder.
#
# Property of Informatica.
# (C) Copyright 2003, 2018 Informatica LLC
# All Rights Reserved. 

#Validate Configuration
raise "The value of root_truststoreFile and icrt_truststoreFile cannot point to the same file. Value specified is: #{node["appintegration_service"]["root_truststoreFile"]}" if node["appintegration_service"]["root_truststoreFile"] == node["appintegration_service"]["icrt_truststoreFile"]


#JRE Install
if node[:platform_family].include?("rhel")
include_recipe "icrt-javainstall::jre"
end

#========================================
# Step 0: Prepare workdir
#========================================
#Setup the temporary directory where all the work will happen.
if node["appintegration_service"]["import-combined-cert-workdir"].nil? || node["appintegration_service"]["import-combined-cert-workdir"].empty?
	user = node['current_user']
	home = node['etc']['passwd'][user]['dir']
	workdir = home
else
	workdir = node["appintegration_service"]["import-combined-cert-workdir"]
end
workdir = workdir + '/' + ".icrttmp"
puts "[truststore_init] Using workdir: " + workdir
directory "Create #{workdir}" do
  owner 'root'
  group 'root'
  mode '0755'
  path "#{workdir}"
  recursive true
  action :create
end

cookbook_file "#{workdir}/import-custom-ca-certs.sh" do
  source 'import-custom-ca-certs.sh'
  owner 'root'
  group 'root'
  mode '0755'
  action :create
end
cookbook_file "#{workdir}/custom-truststore.jks" do
  source 'custom-truststore.jks'
  owner 'root'
  group 'root'
  mode '0555'
  action :create
end
#for debugging
execute "list workdir contents" do
  command  "ls -ltr #{workdir}"
  ignore_failure false
  live_stream true
end

if node["appintegration_service"]["database_jdbc_use_ssl"] == "true" then	
	# populate workdir with source files
	cookbook_file "#{workdir}/generate-mysql-disable-client-cert-emptystore.sh" do
	  source 'generate-mysql-disable-client-cert-emptystore.sh'
	  owner 'root'
	  group 'root'
	  mode '0755'
	  action :create
	end
	cookbook_file "#{workdir}/rds-combined-ca-bundle.pem" do
	  source 'rds-combined-ca-bundle.pem'
	  owner 'root'
	  group 'root'
	  mode '0555'
	  action :create
	end
else
	puts "[truststore_init] Skipping workdir initialization. Not necessary."	
end
#========================================
# Step 1: Generate mysql-disable-client-cert-emptystore.jks for use by jdbc mysql url parameter. See description 
# of default["appintegration_service"]["database_jdbc_client_keystore_file"] for more details.
#========================================
if node["appintegration_service"]["database_jdbc_use_ssl"] == "false" then	
	puts "[truststore_init] Environment does not use AWS RDS data store. Skipping generation of file: " + node["appintegration_service"]["database_jdbc_client_keystore_file"]
elsif File.exist?("#{node["appintegration_service"]["database_jdbc_client_keystore_file"]}") then
	puts "[truststore_init] empty keystore file already exists. Skipping generation of file: " + node["appintegration_service"]["database_jdbc_client_keystore_file"]
else 
	puts "[truststore_init] empty keystore file does not exist. Generating one " + node["appintegration_service"]["database_jdbc_client_keystore_file"]
	
	file "Create #{workdir}/.emptykeystorepwd" do
	  path "#{workdir}/.emptykeystorepwd"
	  content "#{node["appintegration_service"]["database_jdbc_client_keystore_password"]}"
	  owner 'root'
	  group 'root'
	  mode '0700'
	  sensitive true
	  action :create
	end
	
	execute "Generate empty keystore file" do
	  cwd "#{workdir}"
	  command  "./generate-mysql-disable-client-cert-emptystore.sh -w . -ks #{node['appintegration_service']['database_jdbc_client_keystore_file']} -kpf #{workdir}/.emptykeystorepwd"
	  ignore_failure false
	  live_stream true
	end

	file "#{node['appintegration_service']['database_jdbc_client_keystore_file']}" do
	  owner 'tomcat'
	  group 'tomcat'
	  mode '0400'
	end
	
	#TODO: Need to also figure out how to delete .emptykeystorepwd file when the above step fails abnormally.	
	file "#{workdir}/.emptykeystorepwd" do
	  action :delete
	end
	
end

#========================================
# Step 2: Setup icrt_truststore.jks
#========================================
if node["appintegration_service"]["force_truststore_update"] then
  puts "[truststore_init] Force flag present. Updating truststore file. File: " + node["appintegration_service"]["icrt_truststoreFile"]
elsif File.exist?("#{node["appintegration_service"]["icrt_truststoreFile"]}") then
	puts "[truststore_init] Truststore file already exits. Skipping truststore_init.rb steps! File: " + node["appintegration_service"]["icrt_truststoreFile"]
	return
else
	puts "[truststore_init] Truststore file does not exist. Generating #{node["appintegration_service"]["icrt_truststoreFile"]} ..."
end

file "Create #{workdir}/.bundlepwd" do
  path "#{workdir}/.bundlepwd"
  content "changeit"
  owner 'root'
  group 'root'
  mode '0700'
  sensitive true
  action :create
end

# Import AWS RDS CA Certs used to connect using SSL to the RDS MySQL instances
file "Create #{workdir}/.truststorepwd" do
  path "#{workdir}/.truststorepwd"
  content "#{node["appintegration_service"]["icrt_truststorePass"]}"
  owner 'root'
  group 'root'
  mode '0700'
  sensitive true
  action :create
end

execute "copy root-truststore.jks to $workdir/icrt-truststore-temp.jks " do
  command  "cp -p #{node['appintegration_service']['root_truststoreFile']} #{workdir}/icrt-truststore-temp.jks"
  ignore_failure false
  live_stream true
end

execute "Import AWS RDS CA and Customer CA Certs into Truststore" do
  cwd "#{workdir}"
  command  "./import-custom-ca-certs.sh -b #{workdir}/custom-truststore.jks -bpf #{workdir}/.bundlepwd -w . -ts icrt-truststore-temp.jks -tpf #{workdir}/.truststorepwd"
  ignore_failure false
  live_stream true
end

#TODO: Need to also figure out how to delete .truststorepwd file when the above step fails abnormally.
file "#{workdir}/.truststorepwd" do
  action :delete
end

execute "Place icrt_truststore to app environment" do
  cwd "#{workdir}"
  command  "cp -p icrt-truststore-temp.jks #{node["appintegration_service"]["icrt_truststoreFile"]}; ls -ltr $(dirname #{node['appintegration_service']['icrt_truststoreFile']})"
  ignore_failure false
  live_stream true
end

# Place the AWS RDS CA Cert Bundle next to the truststore. This can be used to specify mysql client --ssl-ca argument, etc.
cookbook_file File.dirname(node["appintegration_service"]["icrt_truststoreFile"]) + "/rds-combined-ca-bundle.pem" do
  source 'rds-combined-ca-bundle.pem'
  owner 'tomcat'
  group 'tomcat'
  mode '0444'
  action :create
end

# In some environments such as developer icsdev the same instance of truststore file is shared by various services. So we need
# to be intelligent about when to clean up this file. For now skipping this clean up step and defering it as future improvement.
#file "#{node['appintegration_service']['root_truststoreFile']}" do
#  action :delete
#end

# cleanup workdir
directory "#{workdir}" do
  recursive true
  action :delete
end
