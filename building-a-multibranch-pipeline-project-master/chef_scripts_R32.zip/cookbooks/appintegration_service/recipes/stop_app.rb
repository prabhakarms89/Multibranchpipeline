# Cookbook Name:: appintegration_service
# # # Recipe:: stop_app
# # #
# # # Copyright (c) 2017 The Authors, All Rights Reserved.
#

tomcatPath = node['appintegration_service']['tomcat_install_path']
waitTimeout = node['appintegration_service']['tomcat_stop_waittimeout_sec']
stopwaitTimeout = "10"

include_recipe "appintegration_service::disable_health"

#Stopping tomcat process
execute "Stopping #{node['appintegration_service']['service_name']}" do
   command "/etc/init.d/#{node['appintegration_service']['service_name_prefix']} stop"
   ignore_failure false
   live_stream true
end

Chef::Log.info("Waiting for #{stopwaitTimeout}Sec to settle down the connections")
execute "wait for #{stopwaitTimeout} Sec" do
  command "sleep #{stopwaitTimeout}"
end
