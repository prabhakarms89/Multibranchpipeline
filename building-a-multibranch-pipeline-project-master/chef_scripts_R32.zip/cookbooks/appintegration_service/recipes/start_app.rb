# Cookbook Name:: appintegration_service
# # # Recipe:: start_app
# # #
# # # Copyright (c) 2017 The Authors, All Rights Reserved.
#

if node['appintegration_service']['restart_tomcat']
   execute "Starting #{node['appintegration_service']['service_name']}" do
        command "/etc/init.d/#{node['appintegration_service']['service_name_prefix']} start"
        ignore_failure false
        live_stream true
   end

   http_request "HEAD #{node['appintegration_service']['icrt_runtime_url']}/active-bpel-health/healthcheck" do
      url "#{node['appintegration_service']['icrt_runtime_url']}/active-bpel-health/healthcheck"
      retries 10
      retry_delay 20
      action :head
   end

end
