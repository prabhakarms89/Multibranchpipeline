#
# Cookbook Name:: appintegration_service
# Recipe:: iics-dep

# Copyright (c) 2017 The Authors, All Rights Reserved.

directory "create temp folder for post-deploy #{node['appintegration_service']['iics_dep_deploy_path']}" do
  path "#{node['appintegration_service']['iics_dep_deploy_path']}"
  owner "root"
  group "root"
  mode '0755'
  recursive true
  action :create
end 

template "#{node['appintegration_service']['iics_dep_deploy_path']}/#{node['appintegration_service']['iics_dep_collection']}" do
  source "#{node['appintegration_service']['iics_dep_deploy_templates_path']}/#{node['appintegration_service']['iics_dep_collection']}.erb"
  mode '0755'
end

template "#{node['appintegration_service']['iics_dep_deploy_path']}/#{node['appintegration_service']['iics_dep_environment']}" do
  source "#{node['appintegration_service']['iics_dep_deploy_templates_path']}/#{node['appintegration_service']['iics_dep_environment']}.erb"
  mode '0755'
end

newman "newman_install #{node['appintegration_service']['service_name']}" do
    action :install
end

newman "newman_run #{node['appintegration_service']['service_name']}" do
    postman_collection "#{node['appintegration_service']['iics_dep_deploy_path']}/#{node['appintegration_service']['iics_dep_collection']}"
    postman_environment "#{node['appintegration_service']['iics_dep_deploy_path']}/#{node['appintegration_service']['iics_dep_environment']}"
    ssl_client_cert  "#{node['appintegration_service']['cert-bundle']}"
    ssl_client_key  "#{node['appintegration_service']['cert-key']}"
    ssl_client_passphrase  "#{node['appintegration_service']['icrt_keystorePass']}"
    action :run
end

newman "newman_uninstall #{node['appintegration_service']['service_name']}" do 
    action :remove
end

# Clean up
directory "delete temp folder for post-deploy #{node['appintegration_service']['iics_dep_deploy_path']}" do
  path "#{node['appintegration_service']['iics_dep_deploy_path']}"
  recursive true
  action :delete
end