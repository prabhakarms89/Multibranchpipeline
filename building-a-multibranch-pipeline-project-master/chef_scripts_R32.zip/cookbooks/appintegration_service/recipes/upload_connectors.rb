#
# Cookbook Name:: appintegration_service
# Recipe:: upload_connectors
#
# Copyright 2016, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#

tdate=Time.now.strftime("%Y-%m-%d")
sourceDir=Chef::Config['file_cache_path']+"/connectors_tmp"
artifactoryApiKey = node['appintegration_service']['artifactory_auth_key']

directory "#{sourceDir}" do
  recursive true
  action :create 
end

execute "deleteOldConnectorZip" do
	command "rm connectors.zip"
	only_if	"ls -l connectors.zip"
	cwd  "#{sourceDir}"
end

remote_file "#{sourceDir}/connectors.zip" do
	source "#{node['appintegration_service']['connectorUpdateZipRemote']}"
	headers 'X-JFrog-Art-Api' => artifactoryApiKey
	action :create
end

execute "unzipToTempDir" do
	command "unzip -o #{sourceDir}/connectors.zip -d #{node['appintegration_service']['connectors_path']}-#{tdate}"
end

execute "backupConnectorsDir" do
	command "mv  #{node['appintegration_service']['connectors_path']} #{node['appintegration_service']['connectors_path']}-#{tdate}BU"
	cwd "#{node['appintegration_service']['connectors_path']}"
	only_if { ::Dir.exist?("#{node['appintegration_service']['connectors_path']}")}
end

execute "updateConnectorsDir" do
	command "mv #{node['appintegration_service']['connectors_path']}-#{tdate} #{node['appintegration_service']['connectors_path']}; chown -R tomcat.tomcat #{node['appintegration_service']['connectors_path']}"
	only_if { ::Dir.exist?("#{node['appintegration_service']['connectors_path']}-#{tdate}")}
end
