# Cookbook Name:: appintegration_service
# # Recipe:: config
# #
# # Copyright (c) 2017 The Authors, All Rights Reserved.
#

if node['appintegration_service']['restart_tomcat']
   execute "Stopping #{node['appintegration_service']['service_name']}" do
   command "/etc/init.d/#{node['appintegration_service']['service_name_prefix']} stop"
   ignore_failure false
   live_stream true
  end
end

tomcat_config "#{node['appintegration_service']['service_name']}" do
    install_path "#{node['appintegration_service']['tomcat_install_path']}"
    xms_value "#{node['appintegration_service']['xms_value']}"
    xmx_value "#{node['appintegration_service']['xmx_value']}"
    other_catalina_opts "#{node['appintegration_service']['catalina_opts']}"
    other_java_opts "#{node['appintegration_service']['java_opts']}"
    server_port "#{node['appintegration_service']['server_port']}"
    shutdown_port "#{node['appintegration_service']['shutdown_port']}"
    ajb_port "#{node['appintegration_service']['ajb_port']}"
    additional_access_log_pattern "#{node['appintegration_service']['additional_access_log_pattern']}"
    sslEnabled "#{node['appintegration_service']['sslEnabled']}"
    clientAuth "#{node['appintegration_service']['sslClientAuth']}"
    keystore_alias "#{node['appintegration_service']['keystore_alias']}"
    useCompression "#{node['appintegration_service']['useCompression']}"
    server_ds_avosdb1_maxIdle "#{node['appintegration_service']['server_ds_avosdb1_maxIdle']}"
    server_ds_avosdb1_maxWait "#{node['appintegration_service']['server_ds_avosdb1_maxWait']}"
    server_ds_avosdb1_maxActive "#{node['appintegration_service']['server_ds_avosdb1_maxActive']}"
    database_jdbc_use_ssl "#{node['appintegration_service']['database_jdbc_use_ssl']}"
    database_jdbc_require_ssl "#{node['appintegration_service']['database_jdbc_require_ssl']}"
    database_jdbc_client_keystore_url "#{node['appintegration_service']['database_jdbc_client_keystore_url']}"
    database_jdbc_client_keystore_password "#{node['appintegration_service']['database_jdbc_client_keystore_password']}"
    database_host "#{node['appintegration_service']['database_host']}"
    database_port "#{node['appintegration_service']['database_port']}"
    database_user "#{node['appintegration_service']['database_user']}"
    database_password "#{node['appintegration_service']['database_password']}"
    database_name "#{node['appintegration_service']['database_name']}"
    connectionTimeout_unsecure "#{node['appintegration_service']['connectionTimeout_unsecure']}"
    maxThreads_tomcat_unsecure "#{node['appintegration_service']['maxThreads_tomcat_unsecure']}"
    runtime_host_unsecure_port "#{node['appintegration_service']['runtime_host_unsecure_port']}"
    tomcat_max_threads "#{node['appintegration_service']['tomcat_max_threads']}"
    tomcat_minSpareThreads "#{node['appintegration_service']['tomcat_minSpareThreads']}"
    icrt_keystoreFile "#{node['appintegration_service']['icrt_keystoreFile']}"
    icrt_keystorePass "#{node['appintegration_service']['icrt_keystorePass']}"
    runtime_host_secure_port "#{node['appintegration_service']['runtime_host_secure_port']}"
    icrt_truststoreFile "#{node['appintegration_service']['icrt_truststoreFile']}"
    icrt_truststorePass "#{node['appintegration_service']['icrt_truststorePass']}"
    runtime_api_gateway_port "#{node['appintegration_service']['runtime_api_gateway_port']}"
    ids_Properties_File "#{node['appintegration_service']['ids_Properties_File']}"
    account_database_user "#{node['appintegration_service']['account_database_user']}"
    account_database_password "#{node['appintegration_service']['account_database_password']}"
    account_database_host "#{node['appintegration_service']['account_database_host']}"
    account_database_port "#{node['appintegration_service']['account_database_port']}"
    account_database_name "#{node['appintegration_service']['account_database_name']}"
    session_timeout "#{node['appintegration_service']['session_timeout']}"
    cluster_enable "#{node['appintegration_service']['cluster_enable']}"
    jvm_route "#{node['appintegration_service']['jvm_route']}"
    connectors_path "#{node['appintegration_service']['connectors_path']}"
    action :create
end

tomcat_context_xml "#{node['appintegration_service']['service_name']}" do
    install_path "#{node['appintegration_service']['tomcat_install_path']}"
    application_context "#{node['appintegration_service']['application_context']}"
    database_jdbc_use_ssl "#{node['appintegration_service']['database_jdbc_use_ssl']}"
    database_jdbc_require_ssl "#{node['appintegration_service']['database_jdbc_require_ssl']}"
    database_jdbc_client_keystore_url "#{node['appintegration_service']['database_jdbc_client_keystore_url']}"
    database_jdbc_client_keystore_password "#{node['appintegration_service']['database_jdbc_client_keystore_password']}"
    database_user "#{node['appintegration_service']['database_user']}"
    database_password "#{node['appintegration_service']['database_password']}"
    database_host "#{node['appintegration_service']['database_host']}"
    database_port "#{node['appintegration_service']['database_port']}"
    database_name "#{node['appintegration_service']['database_name']}"
    log_database_user "#{node['appintegration_service']['log_database_user']}"
    log_database_password "#{node['appintegration_service']['log_database_password']}"
    log_database_host "#{node['appintegration_service']['log_database_host']}"
    log_database_port "#{node['appintegration_service']['log_database_port']}"
    log_database_name "#{node['appintegration_service']['log_database_name']}"
    activebpel_ds_activevos_maxTotal "#{node['appintegration_service']['activebpel_ds_activevos_maxTotal']}"
    activebpel_ds_activevos_maxIdle "#{node['appintegration_service']['activebpel_ds_activevos_maxIdle']}"
    activebpel_ds_activevos_maxWaitMillis "#{node['appintegration_service']['activebpel_ds_activevos_maxWaitMillis']}"
    activebpel_ds_log_activevos_maxTotal "#{node['appintegration_service']['activebpel_ds_log_activevos_maxTotal']}"
    activebpel_ds_log_activevos_maxIdle "#{node['appintegration_service']['activebpel_ds_log_activevos_maxIdle']}"
    activebpel_ds_log_activevos_maxWaitMillis "#{node['appintegration_service']['activebpel_ds_log_activevos_maxWaitMillis']}"
    activevos_ds_activevos_maxTotal "#{node['appintegration_service']['activevos_ds_activevos_maxTotal']}"
    activevos_ds_activevos_maxIdle "#{node['appintegration_service']['activevos_ds_activevos_maxIdle']}"
    activevos_ds_activevos_maxWaitMillis "#{node['appintegration_service']['activevos_ds_activevos_maxWaitMillis']}"
    activevos_ai_maxIdle "#{node['appintegration_service']['activevos_ai_maxIdle']}"
    activevos_ai_maxTotal "#{node['appintegration_service']['activevos_ai_maxTotal']}"
    activevos_ai_maxWaitMillis "#{node['appintegration_service']['activevos_ai_maxWaitMillis']}"
    action :create_context_xml
end

template "#{node['appintegration_service']['tomcat_install_path']}/conf/cloud-platform.yaml" do
  source 'tomcat_conf/cloud-platform_yaml.erb'
  owner 'tomcat'
  group 'tomcat'
  mode 00744
  cookbook 'appintegration_service'
  variables ({
       :application_context => node['appintegration_service']['application_context'],
       :external_pod_url => node['appintegration_service']['external_pod_url'],
       :internal_ha_proxy_url => node['appintegration_service']['internal_ha_proxy_url'],
       :internal_opsinsights_ha_proxy_url => node['appintegration_service']['internal_opsinsights_ha_proxy_url'],
       :service_call_restricted_hosts => node['appintegration_service']['service_call_restricted_hosts'],
       :service_call_restricted_ips => node['appintegration_service']['service_call_restricted_ips'],
       :ma_pod_url => node['appintegration_service']['ma_pod_url'],
       :ai_external_pod_url => node['appintegration_service']['ai_external_pod_url'],
       :ai_internal_ha_proxy_url => node['appintegration_service']['ai_internal_ha_proxy_url'],
       :icrt_interactive_elb_url => node['appintegration_service']['icrt_interactive_elb_url'],
       :icrt_keystoreFile => node['appintegration_service']['icrt_keystoreFile'],
       :icrt_keystorePass => node['appintegration_service']['icrt_keystorePass'],    
       :icrt_truststoreFile => node['appintegration_service']['icrt_truststoreFile'],
       :icrt_truststorePass => node['appintegration_service']['icrt_truststorePass'],
       :jls_url => node['appintegration_service']['jls_url'],
       :jls_jaas_username => node['appintegration_service']['jls_jaas_username'],
       :jls_jaas_password => node['appintegration_service']['jls_jaas_password'],
       :jls_sasl_mechanism => node['appintegration_service']['jls_sasl_mechanism'],
       :jls_security_protocol => node['appintegration_service']['jls_security_protocol'],
       :socketTimeout_ids => node['appintegration_service']['socketTimeout_ids'],
       :connectionTimeout_ids => node['appintegration_service']['connectionTimeout_ids'],
       :poolMaxTotal_ids => node['appintegration_service']['poolMaxTotal_ids'],
       :poolMaxPerRoute_ids => node['appintegration_service']['poolMaxPerRoute_ids'],
       :service_unavailable_autoRetry_ids => node['appintegration_service']['service_unavailable_autoRetry_ids'],
       :service_unavailable_MaxRetries_ids => node['appintegration_service']['service_unavailable_MaxRetries_ids'],
       :service_unavailable_RetryInterval_ids => node['appintegration_service']['service_unavailable_RetryInterval_ids'],
       :executionTimeoutInMilliseconds_ids => node['appintegration_service']['executionTimeoutInMilliseconds_ids'],
       :fallbackEnabled_ids => node['appintegration_service']['fallbackEnabled_ids'],
       :circuitBreakerEnabled_ids => node['appintegration_service']['circuitBreakerEnabled_ids'],
       :threadPool_coreSize_ids => node['appintegration_service']['threadPool_coreSize_ids'],
       :threadPool_maximumSize_ids => node['appintegration_service']['threadPool_maximumSize_ids'],
       :threadpool_allowMaximumSizeToDivergeFromCoreSize_ids => node['appintegration_service']['threadpool_allowMaximumSizeToDivergeFromCoreSize_ids'],
       :socketTimeout_ma => node['appintegration_service']['socketTimeout_ma'],
       :connectionTimeout_ma => node['appintegration_service']['connectionTimeout_ma'],
       :poolMaxTotal_ma => node['appintegration_service']['poolMaxTotal_ma'],
       :poolMaxPerRoute_ma => node['appintegration_service']['poolMaxPerRoute_ma'],
       :executionTimeoutInMilliseconds_ma => node['appintegration_service']['executionTimeoutInMilliseconds_ma'],
       :fallbackEnabled_ma => node['appintegration_service']['fallbackEnabled_ma'],
       :circuitBreakerEnabled_ma => node['appintegration_service']['circuitBreakerEnabled_ma'],
       :socketTimeout_session => node['appintegration_service']['socketTimeout_session'],
       :connectionTimeout_session => node['appintegration_service']['connectionTimeout_session'],
       :poolMaxTotal_session => node['appintegration_service']['poolMaxTotal_session'],
       :poolMaxPerRoute_session => node['appintegration_service']['poolMaxPerRoute_session'],
       :executionTimeoutInMilliseconds_session => node['appintegration_service']['executionTimeoutInMilliseconds_session'],
       :fallbackEnabled_session => node['appintegration_service']['fallbackEnabled_session'],
       :circuitBreakerEnabled_session => node['appintegration_service']['circuitBreakerEnabled_session'],
       :socketTimeout_frs => node['appintegration_service']['socketTimeout_frs'],
       :connectionTimeout_frs => node['appintegration_service']['connectionTimeout_frs'],
       :poolMaxTotal_frs => node['appintegration_service']['poolMaxTotal_frs'],
       :poolMaxPerRoute_frs => node['appintegration_service']['poolMaxPerRoute_frs'],
       :executionTimeoutInMilliseconds_frs => node['appintegration_service']['executionTimeoutInMilliseconds_frs'],
       :fallbackEnabled_frs => node['appintegration_service']['fallbackEnabled_frs'],
       :circuitBreakerEnabled_frs => node['appintegration_service']['circuitBreakerEnabled_frs'],
       :socketTimeout_saas_internal => node['appintegration_service']['socketTimeout_saas_internal'],
       :connectionTimeout_sass_internal => node['appintegration_service']['connectionTimeout_sass_internal'],
       :poolMaxTotal_saas_internal => node['appintegration_service']['poolMaxTotal_saas_internal'],
       :poolMaxPerRoute_saas_internal => node['appintegration_service']['poolMaxPerRoute_saas_internal'],
       :executionTimeoutInMilliseconds_saas_internal => node['appintegration_service']['executionTimeoutInMilliseconds_saas_internal'],
       :fallbackEnabled_saas_internal => node['appintegration_service']['fallbackEnabled_saas_internal'],
       :threadPool_coreSize_saas_internal => node['appintegration_service']['threadPool_coreSize_saas_internal'],
       :threadPool_maximumSize_saas_internal => node['appintegration_service']['threadPool_maximumSize_saas_internal'],
       :threadpool_allowMaximumSizeToDivergeFromCoreSize_saas_internal => node['appintegration_service']['threadpool_allowMaximumSizeToDivergeFromCoreSize_saas_internal'],
       :circuitBreakerEnabled_saas => node['appintegration_service']['circuitBreakerEnabled_saas'],
       :socketTimeout_saas_external => node['appintegration_service']['socketTimeout_saas_external'],
       :connectionTimeout_saas_external => node['appintegration_service']['connectionTimeout_saas_external'],
       :poolMaxTotal_saas_external => node['appintegration_service']['poolMaxTotal_saas_external'],
       :poolMaxPerRoute_saas_external => node['appintegration_service']['poolMaxPerRoute_saas_external'],
       :executionTimeoutInMilliseconds_saas_external => node['appintegration_service']['executionTimeoutInMilliseconds_saas_external'],
       :fallbackEnabled_saas_external => node['appintegration_service']['fallbackEnabled_saas_external'],
       :circuitBreakerEnabled_saas_external => node['appintegration_service']['circuitBreakerEnabled_saas_external'],
       :socketTimeout_notification => node['appintegration_service']['socketTimeout_notification'],
       :connectionTimeout_notification => node['appintegration_service']['connectionTimeout_notification'],
       :poolMaxTotal_notification => node['appintegration_service']['poolMaxTotal_notification'],
       :poolMaxPerRoute_notification => node['appintegration_service']['poolMaxPerRoute_notification'],
       :executionTimeoutInMilliseconds_notification => node['appintegration_service']['executionTimeoutInMilliseconds_notification'],
       :fallbackEnabled_notification => node['appintegration_service']['fallbackEnabled_notification'],
       :circuitBreakerEnabled_notification => node['appintegration_service']['circuitBreakerEnabled_notification'],
       :socketTimeout_kms => node['appintegration_service']['socketTimeout_kms'],
       :connectionTimeout_kms => node['appintegration_service']['connectionTimeout_kms'],
       :poolMaxTotal_kms => node['appintegration_service']['poolMaxTotal_kms'],
       :poolMaxPerRoute_kms => node['appintegration_service']['poolMaxPerRoute_kms'],
       :executionTimeoutInMilliseconds_kms => node['appintegration_service']['executionTimeoutInMilliseconds_kms'],
       :fallbackEnabled_kms => node['appintegration_service']['fallbackEnabled_kms'],
       :circuitBreakerEnabled_kms => node['appintegration_service']['circuitBreakerEnabled_kms'],
       :socketTimeout_crs => node['appintegration_service']['socketTimeout_crs'],
       :connectionTimeout_crs => node['appintegration_service']['connectionTimeout_crs'],
       :poolMaxTotal_crs => node['appintegration_service']['poolMaxTotal_crs'],
       :poolMaxPerRoute_crs => node['appintegration_service']['poolMaxPerRoute_crs'],
       :executionTimeoutInMilliseconds_crs => node['appintegration_service']['executionTimeoutInMilliseconds_crs'],
       :fallbackEnabled_crs => node['appintegration_service']['fallbackEnabled_crs'],
       :circuitBreakerEnabled_crs => node['appintegration_service']['circuitBreakerEnabled_crs'],
       :socketTimeout_migration => node['appintegration_service']['socketTimeout_migration'],
       :connectionTimeout_migration => node['appintegration_service']['connectionTimeout_migration'],
       :poolMaxTotal_migration => node['appintegration_service']['poolMaxTotal_migration'],
       :poolMaxPerRoute_migration => node['appintegration_service']['poolMaxPerRoute_migration'],
       :executionTimeoutInMilliseconds_migration => node['appintegration_service']['executionTimeoutInMilliseconds_migration'],
       :fallbackEnabled_migration => node['appintegration_service']['fallbackEnabled_migration'],
       :circuitBreakerEnabled_migration => node['appintegration_service']['circuitBreakerEnabled_migration'],
       :socketTimeout_license => node['appintegration_service']['socketTimeout_license'],
       :connectionTimeout_license => node['appintegration_service']['connectionTimeout_license'],
       :poolMaxTotal_license => node['appintegration_service']['poolMaxTotal_license'],
       :poolMaxPerRoute_license => node['appintegration_service']['poolMaxPerRoute_license'],
	   :executionTimeoutInMilliseconds_license => node['appintegration_service']['executionTimeoutInMilliseconds_license'],
	   :fallbackEnabled_license => node['appintegration_service']['fallbackEnabled_license'],
	   :cloud_shell_session_timeout => node['appintegration_service']['cloud_shell_session_timeout'],
 	   :maxCacheItems_channelservice => node['appintegration_service']['maxCacheItems_channelservice'],
	   :cacheExpiryMillis_channelservice => node['appintegration_service']['cacheExpiryMillis_channelservice'],
	   :executionTimeoutInMilliseconds_channelservice => node['appintegration_service']['executionTimeoutInMilliseconds_channelservice'],
	   :fallbackEnabled_channelservice => node['appintegration_service']['fallbackEnabled_channelservice'],
       :circuitBreakerEnabled_license => node['appintegration_service']['circuitBreakerEnabled_license'],
       :socketTimeout_opsinsights => node['appintegration_service']['socketTimeout_opsinsights'],
       :connectionTimeout_opsinsights => node['appintegration_service']['connectionTimeout_opsinsights'],
       :poolMaxTotal_opsinsights => node['appintegration_service']['poolMaxTotal_opsinsights'],
       :poolMaxPerRoute_opsinsights => node['appintegration_service']['poolMaxPerRoute_opsinsights'],
       :executionTimeoutInMilliseconds_opsinsights => node['appintegration_service']['executionTimeoutInMilliseconds_opsinsights'],
       :fallbackEnabled_opsinsights => node['appintegration_service']['fallbackEnabled_opsinsights'],
       :circuitBreakerEnabled_opsinsights => node['appintegration_service']['circuitBreakerEnabled_opsinsights'],
	   :tenant_config_enabled_check_interval_seconds => node['appintegration_service']['tenant_config_enabled_check_interval_seconds'],
	   :max_events_in_buffer => node['appintegration_service']['max_events_in_buffer'],
	   :events_flush_timeout_seconds => node['appintegration_service']['events_flush_timeout_seconds'],
	   :kinesis_client_thread_count => node['appintegration_service']['kinesis_client_thread_count'],
	   :kinesis_events_stream => node['appintegration_service']['kinesis_events_stream'],
	   :kinesis_events_stream_region => node['appintegration_service']['kinesis_events_stream_region'],
	   :kinesis_events_stream_access_key => node['appintegration_service']['kinesis_events_stream_access_key'],
	   :kinesis_events_stream_secret_key => node['appintegration_service']['kinesis_events_stream_secret_key'],
	   :external_opsinsights_pod_url => node['appintegration_service']['external_opsinsights_pod_url'],
	   :enable_opsinsights => node['appintegration_service']['enable_opsinsights'],
	   :enable_agentauthcache => node['appintegration_service']['enable_agentauthcache'],
	   :max_cache_items_agentauthcache => node['appintegration_service']['max_cache_items_agentauthcache'],
	   :cache_expiry_millis_agentauthcache => node['appintegration_service']['cache_expiry_millis_agentauthcache'],
	   :lock_timeout_millis_agentauthcache => node['appintegration_service']['lock_timeout_millis_agentauthcache'],
	   :refresh_enabled_agentauthcache => node['appintegration_service']['refresh_enabled_agentauthcache'],
	   :queue_capacity_agentauthcache => node['appintegration_service']['queue_capacity_agentauthcache'],
	   :core_pool_size_agentauthcache => node['appintegration_service']['core_pool_size_agentauthcache'],
	   :max_pool_size_agentauthcache => node['appintegration_service']['max_pool_size_agentauthcache'],
	   :keep_alive_sec_agentauthcache => node['appintegration_service']['keep_alive_sec_agentauthcache'],
	   :time_to_refresh_sec_agentauthcache => node['appintegration_service']['time_to_refresh_sec_agentauthcache'],
	   :evict_load_miss_agentauthcache => node['appintegration_service']['evict_load_miss_agentauthcache'],
	   :enable_agentdatacache => node['appintegration_service']['enable_agentdatacache'],
	   :max_cache_items_agentdatacache => node['appintegration_service']['max_cache_items_agentdatacache'],
	   :cache_expiry_millis_agentdatacache => node['appintegration_service']['cache_expiry_millis_agentdatacache'],
	   :lock_timeout_millis_agentdatacache => node['appintegration_service']['lock_timeout_millis_agentdatacache'],
	   :refresh_enabled_agentdatacache => node['appintegration_service']['refresh_enabled_agentdatacache'],
	   :queue_capacity_agentdatacache => node['appintegration_service']['queue_capacity_agentdatacache'],
	   :core_pool_size_agentdatacache => node['appintegration_service']['core_pool_size_agentdatacache'],
	   :max_pool_size_agentdatacache => node['appintegration_service']['max_pool_size_agentdatacache'],
	   :keep_alive_sec_agentdatacache => node['appintegration_service']['keep_alive_sec_agentdatacache'],
	   :time_to_refresh_sec_agentdatacache => node['appintegration_service']['time_to_refresh_sec_agentdatacache'],
	   :evict_load_miss_agentdatacache => node['appintegration_service']['evict_load_miss_agentdatacache'],
	   :retry_count_agentdatacache => node['appintegration_service']['retry_count_agentdatacache'],
	   :retry_wait_time_millis_agentdatacache => node['appintegration_service']['retry_wait_time_millis_agentdatacache']
	   :enable_agentgroupdatacache => node['appintegration_service']['enable_agentgroupdatacache'],
	   :max_cache_items_agentgroupdatacache => node['appintegration_service']['max_cache_items_agentgroupdatacache'],
	   :cache_expiry_millis_agentgroupdatacache => node['appintegration_service']['cache_expiry_millis_agentgroupdatacache'],
	   :retry_count_agentgroupdatacache => node['appintegration_service']['retry_count_agentgroupdatacache'],
	   :retry_wait_time_millis_agentgroupdatacache => node['appintegration_service']['retry_wait_time_millis_agentgroupdatacache']
      })

end

if node['appintegration_service']['application_context'] == "AI"
template "#{node['appintegration_service']['tomcat_install_path']}/conf/ai-rbac.yaml" do
  source 'tomcat_conf/ai-rbac.yaml.erb'
  owner 'tomcat'
  group 'tomcat'
  mode 00744
  cookbook 'appintegration_service'
  variables ({
       })
end    
end

if node['appintegration_service']['restart_tomcat']
   execute "Starting #{node['appintegration_service']['service_name']}" do
   command "/etc/init.d/#{node['appintegration_service']['service_name_prefix']} start"
   ignore_failure false
   live_stream true
  end
  
  http_request "HEAD #{node['appintegration_service']['icrt_runtime_url']}/active-bpel-health/healthcheck" do
      url "#{node['appintegration_service']['icrt_runtime_url']}/active-bpel-health/healthcheck"
      retries 10
      retry_delay 20
      action :head
end
  
end

