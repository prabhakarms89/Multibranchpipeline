# Cookbook Name:: appintegration_service
# Recipe:: db_update
#
# Copyright (c) 2017 The Authors, All Rights Reserved.


if node['appintegration_service']['update_database'] == "true"

	deploy_ddls  "#{node['appintegration_service']['service_name']} deploy ddls" do
		ddls_deploy_path node['appintegration_service']['ddls_deploy_path']
		base_url node['appintegration_service']['base_url']
		action :install
	end

# Process database patch update script

 if !node['appintegration_service']['process_db_patch'].empty?

  node['appintegration_service']['process_db_patch'].each do | sqlfile|

	mysql_post_script " Process database patch update script" do
	  file_location "#{node['appintegration_service']['ddls_deploy_path']}/#{node['appintegration_service']['ddl_update_directory_process']}/#{sqlfile}"
	  mysqlhost "#{node['appintegration_service']['database_host']}"
	  mysqluser "#{node['appintegration_service']['database_user']}"
	  mysqlpassword "#{node['appintegration_service']['database_password']}"
	  mysqlschema "#{node['appintegration_service']['database_name']}"
	  ssl_ca "#{node['appintegration_service']['database_cacert']}"
	  action :run
	end

  end

 end

 # Socrates database patch update script

 if !node['appintegration_service']['socrates_db_patch'].empty?

  node['appintegration_service']['socrates_db_patch'].each do | sqlfile|

	mysql_post_script "Socrates database patch update script" do
	  file_location "#{node['appintegration_service']['ddls_deploy_path']}/#{node['appintegration_service']['ddl_update_directory_socrates']}/#{sqlfile}"
	  mysqlhost "#{node['appintegration_service']['database_host']}"
	  mysqluser "#{node['appintegration_service']['database_user']}"
	  mysqlpassword "#{node['appintegration_service']['database_password']}"
	  mysqlschema "#{node['appintegration_service']['database_name']}"
	  ssl_ca "#{node['appintegration_service']['database_cacert']}"
	  action :run
	end

  end

 end

 
# Account database patch update script do

 if !node['appintegration_service']['account_db_patch'].empty?

  node['appintegration_service']['account_db_patch'].each do | sqlfile|

	mysql_post_script "account database patch update script" do
	  file_location "#{node['appintegration_service']['ddls_deploy_path']}/#{node['appintegration_service']['ddl_update_directory_log']}/#{sqlfile}"
	  mysqlhost "#{node['appintegration_service']['account_database_host']}"
	  mysqluser "#{node['appintegration_service']['account_database_user']}"
	  mysqlpassword "#{node['appintegration_service']['account_database_password']}"
	  mysqlschema "#{node['appintegration_service']['account_database_name']}"
	  ssl_ca "#{node['appintegration_service']['database_cacert']}"
	  action :run
	end

 end

 end

# Process log database patch update script

 if !node['appintegration_service']['process_log_db_patch'].empty?

  node['appintegration_service']['process_log_db_patch'].each do | sqlfile|

	mysql_post_script "Process log database patch update script" do
	  file_location "#{node['appintegration_service']['ddls_deploy_path']}/#{node['appintegration_service']['ddl_update_directory_acct']}/#{sqlfile}"
	  mysqlhost "#{node['appintegration_service']['log_database_host']}"
	  mysqluser "#{node['appintegration_service']['log_database_user']}"
	  mysqlpassword "#{node['appintegration_service']['log_database_password']}"
	  mysqlschema "#{node['appintegration_service']['log_database_name']}"
	  ssl_ca "#{node['appintegration_service']['database_cacert']}"
	  action :run
	end

  end

 end
  

end