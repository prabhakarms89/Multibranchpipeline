resource_name :deploy_bprs

property :artifact_name, String, required: true, default: 'deploy'
property :version, String, required: true, default: '1.0.0-SNAPSHOT'
property :packaging, String, required: true, default: 'tar'
property :strip_components, Numeric, required: true, default: 0
property :remote_file_name, String, required: true, default: 'deploy.tar'
property :install_path, String, default: '/opt/packages/bprs'
property :base_url, String, default: 'ftp://psv28aeserver/releases/bolt/server/florence_Artifacts_ML/lastSuccessfulBuild/'
property :bpr_file, String
property :bpr_deploy_path, String, default: '/opt/packages/bprs/deploy/activevos/bprs/'
property :bpr_type, String
property :artifactory_api_key, String, default: 'AKCp5Zk9KNQmgBRSy9EgfRmVYMoAteYwJguvgwFfghw7RJYmAVFLeVAzgVs1znmB8Yq6ZaPmV'


# # Can we move tomcat tar to copy it from local. Chef wrapper script download this from internet but best option is to get it from yum/nexus

#Validation of given inputs
#

def tarball_uri
  uri = ''
  uri << base_url
  uri << '/' unless uri[-1] == '/'
  uri << "#{remote_file_name}"
  uri
end

def extraction_command
  cmd = "tar -xf #{Chef::Config['file_cache_path']}/#{remote_file_name} -C #{install_path} --strip-components=#{strip_components}"
  cmd
end


action :install do
   log "#{new_resource.artifact_name} installation started" do
       level :info
   end
  package 'tar'

  group "tomcat" do
    action :create
  end

  user "tomcat" do
    gid "tomcat"
    action :create
  end

  directory "#{new_resource.install_path}" do
        recursive true
        action :delete
		only_if {::Dir.exist?"#{new_resource.install_path}"}
  end
  
  directory "#{new_resource.install_path}" do
        owner 'tomcat'
        group 'tomcat'
        mode '0755'
        recursive true
        action :create
  end


  remote_file "#{new_resource.artifact_name} #{new_resource.remote_file_name} #{new_resource.packaging}" do
  	source tarball_uri
  	path "#{Chef::Config['file_cache_path']}/#{new_resource.remote_file_name}"
	headers 'X-JFrog-Art-Api' => new_resource.artifactory_api_key
    action :create
  end

  execute 'extract tomcat tarball' do
    command extraction_command
    action :run
   # creates ::File.join(install_path, 'LICENSE')
  end

  execute "#{new_resource.install_path}" do
  	command "chown -R tomcat:tomcat #{new_resource.install_path}"
    action :run
  end
end

action :extract do
  directory "#{Chef::Config['file_cache_path']}/tmp" do
	recursive true
        action :delete
		only_if {::Dir.exist?"#{Chef::Config['file_cache_path']}/tmp"}
  end
  directory "#{Chef::Config['file_cache_path']}/tmp" do
        action :create
  end
  execute "unzip #{new_resource.bpr_file}" do
    cwd "#{Chef::Config['file_cache_path']}/tmp"
    command "unzip #{new_resource.bpr_deploy_path}/#{new_resource.bpr_type}/#{new_resource.bpr_file}"
  end
end
action :package do
  execute "zip #{new_resource.bpr_file}" do
    cwd "#{Chef::Config['file_cache_path']}/tmp"
    command "zip -r #{new_resource.bpr_deploy_path}/#{new_resource.bpr_type}/#{new_resource.bpr_file} ."
  end
end
