#
#Resource will start/stop/restart tomcat services
#
# We didn't do service because of provision deamon option didn't go well. We will need to fix it in the chef driver version

resource_name :tomcat_service
property :docker, kind_of: [TrueClass, FalseClass], default: true
property :service_name, String, default: "tomcat"

action :start do
  if node["virtualization"]["system"] == 'docker'
    log "Docker can't run services.So we will handle it while provisioning" do
        level :info
    end
  else
     service "#{service_name}" do
       action :start
     end
  end
end

action :stop do
  if node["virtualization"]["system"] == 'docker'
    log "Docker can't run services.So we will handle it while provisioning" do
        level :info
    end
  else
     service "#{service_name}" do
       action :stop
     end
  end
end

action :restart do
  if node["virtualization"]["system"] == 'docker'
    log "Docker can't run services.So we will handle it while provisioning" do
        level :info
    end
  else
     service "#{new_resource.service_name}" do
       action :stop
     end
     service "#{new_resource.service_name}" do
       action :start
     end
  end
end

action :status do
  if node["virtualization"]["system"] == 'docker'
    log "Docker can't run services.So we will handle it while provisioning" do
        level :info
    end
  else
     service "#{new_resource.service_name}" do
       action :status
     end
  end
end

