#All tomcat related context
# context.xml


resource_name :tomcat_context_xml
property :application_context, String, required: true
property :install_path, String, required: true, default: '/opt/tomcat'
property :engine_name, String, default: 'Catalina'
property :host, String, default: 'localhost'
property :database_jdbc_use_ssl, String, default: 'false'
property :database_jdbc_require_ssl, String, default: 'false'
property :database_jdbc_client_keystore_url, String, default: ''
property :database_jdbc_client_keystore_password, String, default: ''
property :database_user, String, required: true, default: 'activevos'
property :database_password, String, required: true, default: ''
property :database_host, String, required: true, default: 'localhost'
property :database_port, String, required: true, default: '3306'
property :database_name, String, default: 'activevos'
property :log_database_user, String, default: 'activevoslog'
property :log_database_password, String, default: ''
property :log_database_host, String, default: 'localhost'
property :log_database_port, String, default: '3306'
property :log_database_name, String, default: 'activevoslog'
property :activebpel_ds_activevos_maxTotal, String, default: '300'
property :activebpel_ds_activevos_maxIdle, String, default: '75'
property :activebpel_ds_activevos_maxWaitMillis, String, default: '5000'
property :activebpel_ds_log_activevos_maxTotal, String, default: '160'
property :activebpel_ds_log_activevos_maxIdle, String, default: '50'
property :activebpel_ds_log_activevos_maxWaitMillis, String, default: '240000'
property :activevos_ds_activevos_maxTotal, String, default: '100'
property :activevos_ds_activevos_maxIdle, String, default: '10'
property :activevos_ds_activevos_maxWaitMillis, String, default: '1000'
property :activevos_ai_maxIdle, String, default: '10'
property :activevos_ai_maxTotal, String, default: '100'
property :activevos_ai_maxWaitMillis, String, default: '1000'
property :template_path, String, default: 'context_xmls'

action :create_context_xml do
	directory "#{new_resource.install_path}/conf/#{new_resource.engine_name}" do
		owner 'tomcat'
		group 'tomcat'
		mode 00755
		recursive true
		action :create
	end

	directory "#{new_resource.install_path}/conf/#{new_resource.engine_name}/#{new_resource.host}" do
		owner 'tomcat'
		group 'tomcat'
		mode 00755
		recursive true
		action :create
	end


    template "#{new_resource.install_path}/conf/#{new_resource.engine_name}/#{new_resource.host}/active-bpel.xml" do
	source "#{new_resource.template_path}/active-bpel.xml.erb"
        owner 'tomcat'
        group 'tomcat'
        mode '0755'
        cookbook 'appintegration_service'
        variables({
			:database_jdbc_use_ssl => new_resource.database_jdbc_use_ssl,
			:database_jdbc_require_ssl => new_resource.database_jdbc_require_ssl,
			:database_jdbc_client_keystore_url => new_resource.database_jdbc_client_keystore_url,
			:database_jdbc_client_keystore_password => new_resource.database_jdbc_client_keystore_password,
            :database_user => new_resource.database_user,
	    :database_password => new_resource.database_password,
	    :database_host => new_resource.database_host,
            :database_port => new_resource.database_port,
	    :database_name => new_resource.database_name,
	    :activebpel_ds_activevos_maxTotal => new_resource.activebpel_ds_activevos_maxTotal,
	    :activebpel_ds_activevos_maxIdle => new_resource.activebpel_ds_activevos_maxIdle,
	    :activebpel_ds_activevos_maxWaitMillis => new_resource.activebpel_ds_activevos_maxWaitMillis,
	    :log_database_user => new_resource.log_database_user,
            :log_database_password => new_resource.log_database_password,
            :log_database_host => new_resource.log_database_host,
            :log_database_port => new_resource.log_database_port,
            :log_database_name => new_resource.log_database_name,
	    :activebpel_ds_log_activevos_maxTotal => new_resource.activebpel_ds_log_activevos_maxTotal,
	    :activebpel_ds_log_activevos_maxIdle => new_resource.activebpel_ds_log_activevos_maxIdle,
	    :activebpel_ds_log_activevos_maxWaitMillis => new_resource.activebpel_ds_log_activevos_maxWaitMillis
        })
        action :create
    end
    template "#{new_resource.install_path}/conf/#{new_resource.engine_name}/#{new_resource.host}/activevos.xml" do
        source "#{new_resource.template_path}/activevos.xml.erb"
        owner 'tomcat'
        group 'tomcat'
        mode '0755'
        cookbook 'appintegration_service'
        variables({
			:database_jdbc_use_ssl => new_resource.database_jdbc_use_ssl,
			:database_jdbc_require_ssl => new_resource.database_jdbc_require_ssl,
			:database_jdbc_client_keystore_url => new_resource.database_jdbc_client_keystore_url,
			:database_jdbc_client_keystore_password => new_resource.database_jdbc_client_keystore_password,
            :database_user => new_resource.database_user,
            :database_password => new_resource.database_password,
            :database_host => new_resource.database_host,
            :database_port => new_resource.database_port,
            :database_name => new_resource.database_name,
	    :activevos_ds_activevos_maxTotal => new_resource.activevos_ds_activevos_maxTotal,
	    :activevos_ds_activevos_maxIdle => new_resource.activevos_ds_activevos_maxIdle,
	    :activevos_ds_activevos_maxWaitMillis => new_resource.activevos_ds_activevos_maxWaitMillis
        })
        action :create
    end
    template "#{new_resource.install_path}/conf/#{new_resource.engine_name}/#{new_resource.host}/activevos-central.xml" do
        source "#{new_resource.template_path}/activevos-central.xml.erb"
        owner 'tomcat'
        group 'tomcat'
        mode '0755'
        cookbook 'appintegration_service'
        action :create
    end
    template "#{new_resource.install_path}/conf/#{new_resource.engine_name}/#{new_resource.host}/activebpel-cert.xml" do
        source "#{new_resource.template_path}/activebpel-cert.xml.erb"
        owner 'tomcat'
        group 'tomcat'
        mode '0755'
        cookbook 'appintegration_service'
        action :create
    end
if "#{new_resource.application_context}" == "AI"
    template "#{new_resource.install_path}/conf/#{new_resource.engine_name}/#{new_resource.host}/activevos-ai.xml" do
        source "#{new_resource.template_path}/activevos-ai_xml.erb"
        owner 'tomcat'
        group 'tomcat'
        mode '0755'
        cookbook 'appintegration_service'
        variables({
			:database_jdbc_use_ssl => new_resource.database_jdbc_use_ssl,
			:database_jdbc_require_ssl => new_resource.database_jdbc_require_ssl,
			:database_jdbc_client_keystore_url => new_resource.database_jdbc_client_keystore_url,
			:database_jdbc_client_keystore_password => new_resource.database_jdbc_client_keystore_password,
            :database_user => new_resource.database_user,
            :database_password => new_resource.database_password,
            :database_host => new_resource.database_host,
            :database_port => new_resource.database_port,
            :database_name => new_resource.database_name,
            :activevos_ai_maxIdle => new_resource.activevos_ai_maxIdle,
            :activevos_ai_maxTotal => new_resource.activevos_ai_maxTotal,
            :activevos_ai_maxWaitMillis => new_resource.activevos_ai_maxWaitMillis
        })
        action :create
     end
end
end
