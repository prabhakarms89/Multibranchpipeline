resource_name :tomcat_install


property :version, String, required: true, default: '8.5.5'
property :install_path, String, default: '/opt/tomcat'
property :remote_path, String, default: 'http://archive.apache.org/dist/tomcat/'
property :exclude_root, kind_of: [TrueClass, FalseClass], default: true
property :exclude_manager, kind_of: [TrueClass, FalseClass], default: true
property :exclude_examples, kind_of: [TrueClass, FalseClass], default: true
property :exclude_docs, kind_of: [TrueClass, FalseClass], default: true
property :service_name, String, default: 'new-service'
property :service_name_prefix, String, default: 'new-service'
property :shutdown_wait, String, default: '20'


# # Can we move tomcat tar to copy it from local. Chef wrapper script download this from internet but best option is to get it from yum/nexus

#Validation of given inputs
#
def major_version
  @@major_version ||= version.split('.')[0]
end


def validate_version
  unless version =~ /\d+.\d+.\d+/
    Chef::Log.fatal("The version must be in X.Y.Z format. Passed value: #{version}")
    raise
  end
end


def tarball_uri
  uri = ''
  uri << remote_path
  uri << '/' unless uri[-1] == '/'
  uri << "tomcat-#{major_version}/v#{version}/bin/apache-tomcat-#{version}.tar.gz"
  uri
end


def extraction_command
  cmd = "tar -xzf #{Chef::Config['file_cache_path']}/apache-tomcat-#{version}.tar.gz -C #{install_path} --strip-components=1"
  cmd << " --exclude='*webapps/ROOT*'" if exclude_root
  cmd << " --exclude='*webapps/manager*'" if exclude_manager
  cmd << " --exclude='*webapps/host-manager*'" if exclude_manager
  cmd << " --exclude='*webapps/examples*'" if exclude_examples
  cmd << " --exclude='*webapps/docs*'" if exclude_docs
  cmd
end


action :install do
   log "Tomcat installation started" do
       level :info
   end
  validate_version
  package 'tar'

  group "tomcat" do
    action :create
  end

  user "tomcat" do
    gid "tomcat"
    action :create
  end

# Permission only for tomcat user Read execute
# Create symlink for tomcat install location
#  directory "#{install_path}/lib/" do
#    action :delete
#    recursive true
#    only_if { ::Dir.exist?("#{install_path}/lib/") || !::File.symlink?("#{install_path}/lib/") }
#  end

Dir["#{new_resource.install_path}/lib/com.activee.*"].each do |path|
  file ::File.expand_path(path) do
    action :delete
  end
end
  directory "#{new_resource.install_path}" do
        owner 'tomcat'
        group 'tomcat'
        mode '0755'
        recursive true
        action :create
  end


  remote_file "apache #{new_resource.version} tarball" do
  	source tarball_uri
  	path "#{Chef::Config['file_cache_path']}/apache-tomcat-#{new_resource.version}.tar.gz"
    action :create_if_missing
  end

  execute 'extract tomcat tarball' do
    command extraction_command
    action :run
    creates ::File.join(new_resource.install_path, 'LICENSE')
  end
  
  execute "#{new_resource.install_path}" do
        command "chmod -R 755  #{new_resource.install_path}"
    action :run
  end

  execute "#{new_resource.install_path}" do
  	command "chown -R tomcat:tomcat #{new_resource.install_path}"
    action :run
  end

  template "/etc/init.d/#{new_resource.service_name_prefix}" do
    source 'tomcat_startup.erb'
    owner 'root'
    group 'root'
    mode '0755'
    cookbook 'tomcat_appintegration'
    variables ({
     :install_path => "#{new_resource.install_path}",
	 :shutdown_wait => "#{new_resource.shutdown_wait}"
     })
    action :create

  end
end
