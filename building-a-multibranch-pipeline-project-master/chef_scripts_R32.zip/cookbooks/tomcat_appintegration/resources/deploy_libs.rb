resource_name :deploy_libs

property :source_url, String, required: true
property :artifactory_api_key, String, default: 'AKCp5Zk9KNQmgBRSy9EgfRmVYMoAteYwJguvgwFfghw7RJYmAVFLeVAzgVs1znmB8Yq6ZaPmV'
property :install_path, String, default: '/opt/tomcat'

action :install do

  installPath = new_resource.install_path
  log "#{new_resource.source_url} deployment to #{new_resource.install_path} started"
  package 'tar'

  group "tomcat"
  user "tomcat" do
    group "tomcat"
  end

  # Permission only for tomcat user Read execute
  # Create symlink for tomcat install location
  tomcatSharedDir = "#{installPath}/shared/"
  directory tomcatSharedDir do
    action :delete
    recursive true
    only_if { ::Dir.exist?(tomcatSharedDir) || !::File.symlink?(tomcatSharedDir) }
  end

  directory installPath do
    owner 'tomcat'
    group 'tomcat'
    mode '0755'
    recursive true
  end

  localLibFile = "#{Chef::Config['file_cache_path']}/deployLibs.tar"

  remote_file localLibFile do
        source new_resource.source_url
        headers 'X-JFrog-Art-Api' => new_resource.artifactory_api_key
  end

  execute "extract dependencies tarball and update #{installPath} ownership" do
    command <<-EOH
      tar -xf #{localLibFile} -C #{installPath}
      chown -R tomcat:tomcat #{installPath}
    EOH
  end
end
