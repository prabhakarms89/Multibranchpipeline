resource_name :deploy_ddls

property :remote_file_name, String, required: true, default: 'ddls.tar'
property :ddls_deploy_path, String, default: '/opt/packages/ddls'
property :base_url, String, default: 'ftp://psv28aeserver/releases/bolt/server/florence_Artifacts_ML/lastSuccessfulBuild'
property :artifactory_api_key, String, default: 'AKCp5bBh9WHoRHb1D5htA6dGRAe8hUtfm4dt1dFVs8Ku1kmz9DQcTogaLAsSKHYukaHfZN7wf'

# # Can we move tomcat tar to copy it from local. Chef wrapper script download this from internet but best option is to get it from yum/nexus

action :install do
  log "ddls installation started"

  package 'tar'

  group "tomcat"
  user "tomcat" do
    gid "tomcat"
  end

  installPath = new_resource.ddls_deploy_path

  directory installPath do
    recursive true
    action :delete
	only_if {::Dir.exist? installPath}
  end
  
  directory installPath do
    owner 'tomcat'
    group 'tomcat'
    mode '0755'
    recursive true
  end

  localFile = "#{Chef::Config['file_cache_path']}/#{new_resource.remote_file_name}"

  remote_file localFile do
  	source "#{base_url}/#{remote_file_name}"
  	headers 'X-JFrog-Art-Api' => new_resource.artifactory_api_key
  end

  execute "extract DDL tarball and update #{installPath} ownership" do
    command <<-EOH
      tar -xf #{localFile} -C #{installPath} --strip-components=1
      chown -R tomcat:tomcat #{installPath}
    EOH
  end
end