#All tomcat related config
# server.xml
# setenv.sh
# TODO: ADD Server.xml ports connection ssl
# get the certification and load to cacert
# infa cert bundle

resource_name :tomcat_config
property :install_path, String, required: true, default: '/opt/tomcat'
property :xms_value, String, required: true, default: '-Xms64m'
property :xmx_value, String, required: true, default: '-Xmx512m'
property :other_catalina_opts, String, required: true, default: ''
property :other_java_opts, String, required: true, default: ''
property :migration_tmpdir, String, required: true, default: '/opt/tomcat/temp'
property :classpaths, String, default: ''
property :server_port, String, default: '8080'
property :shutdown_port, String, default: '8009'
property :ajb_port, String, default: '8001'
property :additional_access_log_pattern, String,default: ''
property :sslEnabled, String, default: 'false'
property :clientAuth, String, default: 'false'
property :useCompression, String, default: 'false'
property :jmx_port, String, default: '8018'
property :template_path, String, default: 'tomcat_conf'
property :server_ds_avosdb1_maxIdle, String, default: '100'
property :server_ds_avosdb1_maxWait, String, default: '10'
property :server_ds_avosdb1_maxActive, String, default: '5000'
property :database_jdbc_use_ssl, String, default: 'false'
property :database_jdbc_require_ssl, String, default: 'false'
property :database_jdbc_client_keystore_url, String, default: ''
property :database_jdbc_client_keystore_password, String, default: ''
property :database_host, String, default: 'localhost'
property :database_port, String, default: '3306'
property :database_user, String, default: 'acitvevos'
property :database_password, String, default: 'password'
property :database_name, String, default: 'activevos'
property :connectionTimeout_unsecure, String, default: '20000'
property :maxThreads_tomcat_unsecure, String, default: '300'
property :runtime_host_unsecure_port, String, default: '8080'
property :tomcat_max_threads, String, default: '300'
property :tomcat_minSpareThreads, String, default: '4'
property :icrt_keystoreFile, String, default: 'icrt-keystore.jks'
property :icrt_keystorePass, String, default: 'changeit'
property :runtime_host_secure_port, String, default: '8443'
property :icrt_truststoreFile, String, default: 'icrt-trustore.jks'
property :icrt_truststorePass, String, default: 'changeit'
property :runtime_api_gateway_port, String, default: '9443'
property :ids_Properties_File, String, default: 'conf/cloud-platform.properties'
property :account_database_user, String, default: 'activevosacct'
property :account_database_password, String, default: 'password'
property :account_database_host, String, default: 'localhost'
property :account_database_port, String, default: '3306'
property :account_database_name, String, default: 'activevosacct'
property :session_timeout, String, default: ''
property :cluster_enable, String, default: 'false'
property :jvm_route, String, default: ''
property :connectors_path, String, default: "/opt/connectors"
property :keystore_alias, String, default: "icrt"

action :create do
    template "#{new_resource.install_path}/bin/setenv.sh" do
        source "#{new_resource.template_path}/tomcat_setenv.erb"
        owner 'tomcat'
        group 'tomcat'
        mode '0755'
        cookbook 'appintegration_service'
        variables({
            :xms => new_resource.xms_value,
            :xmx => new_resource.xmx_value,
            :install_path => new_resource.install_path,
            :other_catalina_opts => new_resource.other_catalina_opts,
            :other_java_opts => new_resource.other_java_opts,
            :classpaths => new_resource.classpaths,
            :sslEnabled => new_resource.sslEnabled,
            :icrt_keystoreFile => new_resource.icrt_keystoreFile,
            :icrt_keystorePass => new_resource.icrt_keystorePass,
            :runtime_host_secure_port => new_resource.runtime_host_secure_port,
            :icrt_truststoreFile => new_resource.icrt_truststoreFile,
            :icrt_truststorePass => new_resource.icrt_truststorePass,
            :connectors_path => new_resource.connectors_path,
            :prometheus_jmx_exporter_jar => "#{node["appintegration_service"]["prometheus-jmx-exporter"]["dir"]}/#{node["appintegration_service"]["prometheus-jmx-exporter"]["jar"]}",
            :prometheus_jmx_exporter_config_file => "#{node["appintegration_service"]["prometheus-jmx-exporter"]["dir"]}/#{node["appintegration_service"]["prometheus-jmx-exporter"]["config_file"]}"
        })
        action :create
    end
    template "#{new_resource.install_path}/conf/web.xml" do
        source "#{new_resource.template_path}/tomcat_web_xml.erb"
        owner 'tomcat'
        group 'tomcat'
        mode '0755'
        cookbook 'appintegration_service'
        variables({
            :session_timeout => new_resource.session_timeout
        })
        action :create
    end

    template "#{new_resource.install_path}/conf/server.xml" do
        source "#{new_resource.template_path}/tomcat_server_xml.erb"
        owner 'tomcat'
        group 'tomcat'
        mode '0755'
        cookbook 'appintegration_service'
        variables ({
            :server_ds_avosdb1_maxIdle => new_resource.server_ds_avosdb1_maxIdle,
            :server_ds_avosdb1_maxWait => new_resource.server_ds_avosdb1_maxWait,
            :server_ds_avosdb1_maxActive => new_resource.server_ds_avosdb1_maxActive,
			:database_jdbc_use_ssl => new_resource.database_jdbc_use_ssl,
			:database_jdbc_require_ssl => new_resource.database_jdbc_require_ssl,
			:database_jdbc_client_keystore_url => new_resource.database_jdbc_client_keystore_url,
			:database_jdbc_client_keystore_password => new_resource.database_jdbc_client_keystore_password,
            :database_host => new_resource.database_host,
            :database_port => new_resource.database_port,
            :database_user => new_resource.database_user,
            :database_password => new_resource.database_password,
            :database_name => new_resource.database_name,
            :connectionTimeout_unsecure => new_resource.connectionTimeout_unsecure,
            :maxThreads_tomcat_unsecure => new_resource.maxThreads_tomcat_unsecure,
            :runtime_host_unsecure_port=> new_resource.runtime_host_unsecure_port,
            :tomcat_max_threads => new_resource.tomcat_max_threads,
            :tomcat_minSpareThreads => new_resource.tomcat_minSpareThreads,
            :icrt_keystoreFile => new_resource.icrt_keystoreFile,
            :icrt_keystorePass => new_resource.icrt_keystorePass,
            :runtime_host_secure_port => new_resource.runtime_host_secure_port,
            :icrt_truststoreFile => new_resource.icrt_truststoreFile,
            :icrt_truststorePass => new_resource.icrt_truststorePass,
            :runtime_api_gateway_port => new_resource.runtime_api_gateway_port,
            :ids_Properties_File => new_resource.ids_Properties_File,
            :account_database_user => new_resource.account_database_user,
            :account_database_password => new_resource.account_database_password,
            :account_database_host => new_resource.account_database_host,
            :account_database_port => new_resource.account_database_port,
            :account_database_name => new_resource.account_database_name,
            :cluster_enable => new_resource.cluster_enable,
            :jvm_route => new_resource.jvm_route,
	    :keystore_alias => new_resource.keystore_alias

        })
        action:create
    end

    template "#{new_resource.install_path}/conf/catalina.properties" do
        source "#{new_resource.template_path}/catalina.properties.erb"
        owner 'tomcat'
        group 'tomcat'
        mode '0755'
        cookbook 'appintegration_service'
        action :create
    end

end
