#base URls

default["global_infa_properties"]["artifact_store"] = "jenkins"
default["global_infa_properties"]["base_url"] = "file:///opt/packages"


# Security Filter Properties
default["global_infa_properties"]["authfilter_ids_url"] = "#{node["global_infa_properties"]["idsPodUrl"]}/identity-service"
default["global_infa_properties"]["authfilter_blacklist_tokens_file_url"]="/opt/extras/token-blacklist/token-blacklist.txt"
default["global_infa_properties"]["connection_timeout"] = "10000"
default["global_infa_properties"]["socket_timeout"]="30000"
default["global_infa_properties"]["connection_request_timeout"]="30000"
default["global_infa_properties"]["max_connection_total"] = "300"
default["global_infa_properties"]["max_connection_per_route"]="75"
default["global_infa_properties"]["hibernate_sql_exception_log_level"]="ERROR"
default["global_infa_properties"]["authfilter_httpclient_maxconnection"]=100


#log4j properties for catalina.out
default["global_infa_properties"]["log_appender"] = "org.apache.log4j.DailyRollingFileAppender"  
default['global_infa_properties']['log_max_backup_index'] = "10"
default['global_infa_properties']['log_date_pattern'] = "'.'yyyy-MM-dd"

#log4j properties for stdout
default["global_infa_properties"]["stdout_enabled"] = false

#service urls
default["global_infa_properties"]["ids_url"] = "#{node["global_infa_properties"]["idsPodUrl"]}/identity-service"
default["global_infa_properties"]["ma_url"] = "#{node["global_infa_properties"]["idsPodUrl"]}/ma"
default["global_infa_properties"]["content_repo_url"] = "#{node["global_infa_properties"]["contentUrl"]}/content-repo"
default["global_infa_properties"]["package_manager_url"] = "#{node["global_infa_properties"]["commonUrl"]}/package-manager"


default["global_infa_properties"]["frs_url"] = "#{node["global_infa_properties"]["podUrl"]}/frs"
default["global_infa_properties"]["frs_internal_url"] = "#{node["global_infa_properties"]["internalPodUrl"]}/frs"
default["global_infa_properties"]["ss_url"] = "#{node["global_infa_properties"]["podUrl"]}/session-service"
default["global_infa_properties"]["ss_internal_url"] = "#{node["global_infa_properties"]["internalPodUrl"]}/session-service"
default["global_infa_properties"]["ns_url"] = "#{node["global_infa_properties"]["podUrl"]}/notification-service"
default["global_infa_properties"]["ns_internal_url"] = "#{node["global_infa_properties"]["internalPodUrl"]}/notification-service"
default["global_infa_properties"]["migration_url"] = "#{node["global_infa_properties"]["podUrl"]}/migration"
default["global_infa_properties"]["migration_internal_url"] = "#{node["global_infa_properties"]["internalPodUrl"]}/migration"
default["global_infa_properties"]["lics_url"] = "#{node["global_infa_properties"]["podUrl"]}/license-service"
default["global_infa_properties"]["lics_internal_url"] = "#{node["global_infa_properties"]["internalPodUrl"]}/license-service"
default["global_infa_properties"]["sch_url"] = "#{node["global_infa_properties"]["podUrl"]}/scheduler-service"
default["global_infa_properties"]["sch_internal_url"] = "#{node["global_infa_properties"]["internalPodUrl"]}/scheduler-service"
default["global_infa_properties"]["bundle_url"] = "#{node["global_infa_properties"]["podUrl"]}/bundle-service"
default["global_infa_properties"]["bundle_internal_url"] = "#{node["global_infa_properties"]["internalPodUrl"]}/bundle-service"
default["global_infa_properties"]["saas_url"] = "#{node["global_infa_properties"]["podUrl"]}/saas"
default["global_infa_properties"]["saas_internal_url"] = "#{node["global_infa_properties"]["internalPodUrl"]}/saas"
default["global_infa_properties"]["kms_url"] = "#{node["global_infa_properties"]["podUrl"]}/kms-service"
default["global_infa_properties"]["kms_internal_url"] = "#{node["global_infa_properties"]["internalPodUrl"]}/kms-service"
default["global_infa_properties"]["ps_url"] = "#{node["global_infa_properties"]["podUrl"]}/preference-service"
default["global_infa_properties"]["ps_internal_url"] = "#{node["global_infa_properties"]["internalPodUrl"]}/preference-service"
default["global_infa_properties"]["audit_url"] = "#{node["global_infa_properties"]["podUrl"]}/auditlog-service"
default["global_infa_properties"]["audit_internal_url"] = "#{node["global_infa_properties"]["internalPodUrl"]}/auditlog-service"
default["global_infa_properties"]["jls-di_url"] = "#{node["global_infa_properties"]["podUrl"]}/jls-di"
default["global_infa_properties"]["jls-di_internal_url"] = "#{node["global_infa_properties"]["internalPodUrl"]}/jls-di"
default["global_infa_properties"]["p2pms_internal_url"] = "#{node["global_infa_properties"]["internalPodUrl"]}/p2pms"


# SSL options
default["global_infa_properties"]["certsLocation"] = "/etc/ssl/infaca"
default["global_infa_properties"]["generateCerts"] = "false"
default["global_infa_properties"]["sslEnabled"] = "true"
default["global_infa_properties"]["sslClientAuth"] = "true"
default["global_infa_properties"]["dbSslClientAuthSupported"] = "true"
default["global_infa_properties"]["sslKeystorePassword"] = "changeit"
default["global_infa_properties"]["sslTruststorePassword"] = "changeit"
default["global_infa_properties"]["cacert"] = "#{node["global_infa_properties"]["certsLocation"]}/ca-bundle.pem"
default["global_infa_properties"]["truststoreUrl"] = "https://artifacts.cloudtrust.rocks/iics-generic/Certificates/infaCacertsFile"
default["global_infa_properties"]["nodeTokenUrl"] ="169.254.169.254/latest/dynamic/instance-identity/pkcs7"

if "#{node['global_infa_properties']['generateCerts']}" == 'true'
	unless node['global_infa_properties']['vaultUrl']
	  Chef::Application.fatal!("The vaultUrl attribute isn't set, please update your environment file!")
	end


	unless node['global_infa_properties']['vaultRole']
	  Chef::Application.fatal!("The vaultRole attribute isn't set, please update your environment file!")
	end
end

default["global_infa_properties"]["logging_client_props"]["security.protocol"] = "SSL"
default["global_infa_properties"]["logging_client_props"]["ssl.key.password"] = "changeit"
default["global_infa_properties"]["logging_client_props"]["ssl.keystore.location"] = ""
default["global_infa_properties"]["logging_client_props"]["ssl.keystore.password"] = "changeit"
default["global_infa_properties"]["logging_client_props"]["ssl.truststore.location"] = "#{node["global_infa_properties"]["certsLocation"]}/truststore.jks"
default["global_infa_properties"]["logging_client_props"]["ssl.truststore.password"] = "changeit"

#java
default["global_infa_properties"]["jre_version"] = "8u161"
default["global_infa_properties"]["artifactory_key"] = "AKCp2WY1MiYWaT7ysy6pxuP85MU7ugcYvZvaX7SeGFCMdyZcRZGGyvAMHBs6RBc9hb7jTBD5N"


# tomcat properties
default["global_infa_properties"]["acceptCount"] = "100"
default["global_infa_properties"]["maxThreads"] = "200"
default["global_infa_properties"]["keepAliveTimeout"] = "20000"

# Db additional properties
default["global_infa_properties"]["dbAdditionalConfig"] = "&requireSSL=true&clientCertificateKeyStoreUrl=file:#{node["global_infa_properties"]["certsLocation"]}/empty.jks&clientCertificateKeyStorePassword=changeit&clientCertificateKeyStoreType=JKS&trustCertificateKeyStoreUrl=file:#{node["global_infa_properties"]["certsLocation"]}/truststore.jks&trustCertificateKeyStoreType=JKS&trustCertificateKeyStorePassword=changeit"


#Log options
default["global_infa_properties"]["log_level"] = "INFO"
default["global_infa_properties"]["infa_log_level"] = "DEBUG"

#cloud provider
default["global_infa_properties"]["cloud_provider"] = "aws"

# Do we need to backup remote_file downloads, usually we shouldn't
default["global_infa_properties"]["remote_file_backup"] = false

# rolling upgrade properties
default["global_infa_properties"]["rolling_upgrade_config_path"]="/tmp/config.properties"