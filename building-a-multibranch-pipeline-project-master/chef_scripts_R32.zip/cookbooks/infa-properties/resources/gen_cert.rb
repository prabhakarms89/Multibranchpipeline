resource_name :gen_cert
property :serviceUser, String, required: true
property :certName, String, required: false, default: ''
property :user_name, String, default: 'tomcat'
property :user_group, String, default: 'tomcat'
property :update_jre_jce, String, default: 'false'
property :issuerCertRequired, kind_of: [TrueClass, FalseClass], default: false



action :create do
    if "#{node['global_infa_properties']['generateCerts']}" == 'true'

        jdk_install "Install Jdk from infa_properties cookbook" do
           update_jce "#{update_jre_jce}"
           action:install
        end

    	group "#{user_group}" do
           action :create
        end

        user "#{user_name}" do
           gid "#{user_group}"
           action :create
        end

    	directory "#{node['global_infa_properties']['certsLocation']}" do
            owner "#{user_name}"
            group "#{user_group}"
            mode '0755'
            recursive true
            action :create
        end

        template "#{node['global_infa_properties']['certsLocation']}/#{serviceUser}_gen_cert.sh" do
            source 'gen_cert.erb'
            owner 'root'
            group 'root'
            mode '0700'
            cookbook 'infa-properties'
            variables ({
            	:serviceUser => "#{serviceUser}",                        
                :jdkhome => "#{node['javainstall']['jdkhome']}",
                :vaultUrl =>  "#{node['global_infa_properties']['vaultUrl']}",
                :vaultRole => "#{node['global_infa_properties']['vaultRole']}",
                :truststoreUrl =>  "#{node['global_infa_properties']['truststoreUrl']}",
                :artifcatoryToken => "#{node['global_infa_properties']['artifactory_key']}",
                :keystorePass => "#{node['global_infa_properties']['sslKeystorePassword']}",
                :truststorePass => "#{node['global_infa_properties']['sslTruststorePassword']}",
                :userName => "#{user_name}",
                :userGroup => "#{user_group}",
                :nodeTokenUrl => "#{node['global_infa_properties']['nodeTokenUrl']}",
                :issuerCertRequired => "#{issuerCertRequired}",
                :certName => "#{certName}"
            })
        action :create
        end

    
        
        script 'Gernating service certs' do
           interpreter "bash"
           code <<-EOH
             cd #{node['global_infa_properties']['certsLocation']}      
    		 ./#{serviceUser}_gen_cert.sh
           EOH
        end
    end
end