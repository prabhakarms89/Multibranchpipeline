resource_name :jmx_config
property :jdbc_url, String, required: true, default: ''
property :install_path, String , required: true, default: '/opt/tomcat'


action :create do
  directory "#{install_path}/infa_conf" do
    owner 'tomcat'
    group 'tomcat'
    mode 00755
    recursive true
    action :create
  end
  template "#{install_path}/infa_conf/jmx_attrs.conf" do
    source 'jmx_attrs_conf.erb'
    owner 'tomcat'
    group 'tomcat'
    mode '0755'
    cookbook 'infa-properties'
    variables ({
      :jdbc_url => jdbc_url
      })
    action:create
  end

end