resource_name :log4j_properties
property :log_appender, String, required: false
property :log_level, String, required: true, default: 'INFO'
property :infa_log_level, String, required: false
property :hibernate_sql_exception_log_level, String, required: true, default: 'ERROR'
property :log_max_backup_index, String, required: false
property :log_date_pattern, String, required: false
property :additional_catalina_log_pattern, String, required: true, default: ''
property :install_path, String , required: true, default: '/opt/tomcat'


action :create do
  directory "#{install_path}/infa_conf" do
    owner 'tomcat'
    group 'tomcat'
    mode 00755
    recursive true
    action :create
  end
  template "#{install_path}/infa_conf/log4j.properties" do
    source 'tomcat_log4j_properties.erb'
    owner 'tomcat'
    group 'tomcat'
    mode '0755'
    cookbook 'infa-properties'
    variables ({
      :log_appender => log_appender,
      :log_level => log_level,
      :infa_log_level => infa_log_level,
      :hibernate_sql_exception_log_level => hibernate_sql_exception_log_level,
      :additional_catalina_log_pattern => additional_catalina_log_pattern,
      :log_max_backup_index => log_max_backup_index,
      :log_date_pattern => log_date_pattern
      })
    action :create
  end

end
