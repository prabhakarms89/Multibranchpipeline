
resource_name :provision_docker_app
property :service_name, String,required: true,default: 'microservice'
property :appinstance_count,String,required: true,default: '1'
property :dbinstance_name,String,required: true, default: 'mysql'
property :apprecipe,String,required:false
property :volmount, String,required:true,default: '/opt/tomcat'
property :ports,String,required:true,default: '8080'

action :createapp do
  machine "#{service_name}" do
      recipe apprecipe
      recipe 'identity-service::app'
      recipe 'session-service::app'
      machine_options :docker_options => {
         :base_image => {
             :name => 'centos',
             :repository => 'centos',
             :tag => 'latest'
         },
        # :command => '/bin/bash -c "/etc/init.d/tomcat start ; tail -f /opt/tomcat/logs/catalina.out"',
        # :ports => ["8080:8080"]
         link: ["#{dbinstance_name}:#{dbinstance_name}"],
         volumes: ["#{volmount}:#{volmount}"],
         ports: ["#{ports}:#{ports}"] ,

         command: '/bin/bash -c "/etc/init.d/tomcat start ; tail -f /opt/tomcat/logs/catalina.out"'
         #volumes:[/var/log:/opt/tomcat/logs]
    },
      :convergence_options => {
      :ssl_verify_mode => 'verify_none'
    }
   end
end
