
resource_name :provision_docker_db
property :service_name, String,required: true,default: 'microservice'
property :dbinstance_name, String, required: true, default: 'mysql'
property :dbinstance_count, String, required:true,default: '1'
property :dbtype,String, required:true,default: 'mysql'
property :dbversion,String,required:true,default: '5.6'
property :dbrecipe,String,required:false
property :volmount, String,required:true,default: '/opt/tomcat'
property :ports,String,required:true,default: '8080'
property :mysqlrootpassword, String,required:true,default: 'change'

action :createdb do
  machine "#{dbinstance_name}" do
    recipe dbrecipe
    recipe 'identity-service::db'
    recipe 'session-service::db'
    machine_options docker_options: {
           base_image: {
           name: 'mysql',
           repository: 'mysql',
           tag:  '5.6'
         },
      #   env: {
    #        "MYSQL_ROOT_PASSWORD" => 'change'
      #    },
          env:[ "MYSQL_ROOT_PASSWORD=#{mysqlrootpassword}"],
          command: '/entrypoint.sh mysqld'
       },
       convergence_options: {
       ssl_verify_mode:'verify_none'
     }
   end
end
