#
# Cookbook Name:: provision
# Recipe:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.
dot 'testing' do
  action :create
end
