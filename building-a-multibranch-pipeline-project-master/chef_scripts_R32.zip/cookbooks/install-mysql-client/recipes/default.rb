#
# Cookbook Name:: install-mysql-client
# Recipe:: default
#
# Copyright 2016, Informatica
#
# All rights reserved - Do Not Redistribute
#

# The mysql package has a different name on Centos 7
package 'Install mysql client' do
  case node['platform_version'].to_i
  when 7
    package_name 'mariadb'
  else
    package_name 'mysql'
  end
end