#All tomcat related config
# server.xml
# setenv.sh
# TODO: ADD Server.xml ports connection ssl
# get the certification and load to cacert
# infa cert bundle

resource_name :icrt_haproxy_consul_config
property :service_name, String, required: true
property :server_port, String,required: true, default: '443'
property :is_in_internal_haproxy, String, required: true, default: 'false'
property :is_in_external_haproxy, String, required: true, default: 'false'
property :is_in_idsma_haproxy, String, required: true, default: 'false'



action :create do

    directory "#{node['icrt_consulConfig']['consul_install_path']}/infa_conf" do
        owner 'root'
        group 'root'
        mode '0755'
        recursive true
        action :create
    end
    
    directory "#{node['icrt_consulConfig']['consul_install_path']}/bin" do
        owner 'root'
        group 'root'
        mode '0755'
        recursive true
        action :create
    end
  
    template "#{node['icrt_consulConfig']['consul_install_path']}/infa_conf/#{service_name}_chef_config.json" do
        source 'chef_config_json.erb'
        owner 'root'
        group 'root'
        mode '0444'
        cookbook 'icrt_haproxyConsul'
        variables ({
            :server_port =>  "#{server_port}",
            :haproxy_pid_path => "#{node['icrt_haproxyConsul']['haproxy_pid_path']}/haproxy.pid",
            :service_name => "#{service_name}",                        
            :host_name => "#{node['hostname']}",
             # this is directly read from environmnet and not passed as argument by caller. 
            :podname => "#{node['icrt_consulConfig']['podname']}",
            :consul_install_path => "#{node['icrt_consulConfig']['consul_install_path']}",
            :is_in_internal_haproxy => "#{is_in_internal_haproxy}",
            :is_in_external_haproxy => "#{is_in_external_haproxy}",
            :is_in_idsma_haproxy => "#{is_in_idsma_haproxy}"
        })
    action :create
    end
    
end

