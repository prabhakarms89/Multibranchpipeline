#All tomcat related config
# server.xml
# setenv.sh
# TODO: ADD Server.xml ports connection ssl
# get the certification and load to cacert
# infa cert bundle

resource_name :icrt_haproxy_consul_restart_check
property :service_name, String, required: true

action :create do

    directory "#{node['icrt_consulConfig']['consul_install_path']}/infa_conf" do
        owner 'root'
        group 'root'
        mode '0755'
        recursive true
        action :create
    end
    
    directory "#{node['icrt_consulConfig']['consul_install_path']}/bin" do
        owner 'root'
        group 'root'
        mode '0755'
        recursive true
        action :create
    end
      
    template "#{node['icrt_consulConfig']['consul_install_path']}/bin/#{service_name}_restart_check.sh" do
         source 'check_restart.erb'
         owner 'root'
         group 'root'
         mode '0755'
         cookbook 'icrt_haproxyConsul'
         variables ({           
         })
    action :create
    end
    

end

