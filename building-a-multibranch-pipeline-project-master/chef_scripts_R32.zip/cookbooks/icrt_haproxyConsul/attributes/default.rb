#
# environments
#
default["icrt_haproxyConsul"]["enable_stats"]= "true"
default["icrt_haproxyConsul"]["service_name"] = "ICAI-haproxy"
default["icrt_haproxyConsul"]["haproxy_config_path"] = "/etc/haproxy"
default["icrt_haproxyConsul"]["haproxy_pid_path"] = "/var/run"
default["icrt_haproxyConsul"]["haproxy_socket_path"] = "/var/run"
default["icrt_haproxyConsul"]["cacert"] = "/etc/ssl/infaca/ca-bundle.pem"
default["icrt_haproxyConsul"]["cert"] = "/etc/ssl/infaca/host-key-bundle.pem"
default["icrt_haproxyConsul"]["public_cert"] ="/etc/ssl/infaca/ai.pod1.dev2.informaticacloud.com.pem"
default["icrt_haproxyConsul"]["public_cert_file"] ="ai.pod1.dev2.informaticacloud.com.pem"
default["icrt_haproxyConsul"]["podname"] ="ai.pod1.dev2"
default["icrt_haproxyConsul"]["cors_origin_list"] ="https://ids.ics.dev\nhttps://pod.ics.dev:444"
default["icrt_haproxyConsul"]["is_in_internal_haproxy"] ="false"
default["icrt_haproxyConsul"]["is_in_external_haproxy"] ="false"
default["icrt_haproxyConsul"]["is_in_idsma_haproxy"] ="false"
default["icrt_haproxyConsul"]["enable_accept_proxy"] ="false"
#Internal ha-proxy config
default["icrt_haproxyConsul"]["intha_timeout_connect_sec"] ="5"
default["icrt_haproxyConsul"]["intha_timeout_check_sec"] ="5"
default["icrt_haproxyConsul"]["intha_timeout_client_sec"] ="30"
default["icrt_haproxyConsul"]["intha_timeout_server_sec"] ="110"
#External ha-proxy config
default["icrt_haproxyConsul"]["extha_timeout_connect_sec"] ="5"
default["icrt_haproxyConsul"]["extha_timeout_check_sec"] ="5"
default["icrt_haproxyConsul"]["extha_timeout_client_sec"] ="30"
default["icrt_haproxyConsul"]["extha_timeout_server_sec"] ="110"

