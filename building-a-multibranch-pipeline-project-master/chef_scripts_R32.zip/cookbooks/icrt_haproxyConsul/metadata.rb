name 'icrt_haproxyConsul'
maintainer 'The Authors'
maintainer_email 'you@example.com'
license 'all_rights'
description 'Configures Consul'
long_description 'Configures Consul'
version '0.5.0'

depends 'icrt_consulConfig'

