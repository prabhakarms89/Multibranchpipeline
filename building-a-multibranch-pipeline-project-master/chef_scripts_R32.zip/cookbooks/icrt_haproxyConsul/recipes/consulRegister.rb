consul_service "#{node['icrt_haproxyConsul']['service_name']}" do  
  service_name "#{node['icrt_haproxyConsul']['service_name']}"  
  action :register
end
