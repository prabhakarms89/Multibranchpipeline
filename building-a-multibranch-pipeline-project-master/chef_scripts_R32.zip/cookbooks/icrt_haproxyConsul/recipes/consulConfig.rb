
icrt_haproxy_consul_config "#{node['icrt_haproxyConsul']['service_name']}" do
  service_name "#{node['icrt_haproxyConsul']['service_name']}"
  is_in_internal_haproxy  "#{node['icrt_haproxyConsul']['is_in_internal_haproxy']}"
  is_in_external_haproxy  "#{node['icrt_haproxyConsul']['is_in_external_haproxy']}"
  is_in_idsma_haproxy  "#{node['icrt_haproxyConsul']['is_in_idsma_haproxy']}"     
  action :create
end

icrt_haproxy_consul_restart_check "#{node['icrt_haproxyConsul']['service_name']}" do  
  service_name "#{node['icrt_haproxyConsul']['service_name']}" 
  action :create
end
