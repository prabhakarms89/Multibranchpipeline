group "haproxy" do
    action :create
end

user "haproxy" do
    gid "haproxy"
    action :create
end
   
directory node['icrt_haproxyConsul']['haproxy_config_path'] do
    owner 'haproxy'
    group 'haproxy'
    mode '0755'
    recursive true
    action :create
end

directory node['icrt_haproxyConsul']['haproxy_socket_path'] do
    owner 'haproxy'
    group 'haproxy'
    mode '0755'
    recursive true
    action :create
end

directory node['icrt_haproxyConsul']['haproxy_pid_path'] do
    owner 'haproxy'
    group 'haproxy'
    mode '0755'
    recursive true
    action :create
end

template "#{node['icrt_haproxyConsul']['haproxy_config_path']}/haproxy_consul_config.ctmpl" do
  source 'haproxy_external_consul.erb'
  owner 'haproxy'
  group 'haproxy'
  mode 00744
  variables ({
       :haproxy_config_path => node['icrt_haproxyConsul']['haproxy_config_path'],       
       :haproxy_pid_path => node['icrt_haproxyConsul']['haproxy_pid_path'],
       :haproxy_socket_path => node['icrt_haproxyConsul']['haproxy_socket_path'],
       :extha_timeout_connect_sec => node['icrt_haproxyConsul']['extha_timeout_connect_sec'],
       :extha_timeout_check_sec => node['icrt_haproxyConsul']['extha_timeout_check_sec'],
       :extha_timeout_client_sec => node['icrt_haproxyConsul']['extha_timeout_client_sec'],
       :extha_timeout_server_sec => node['icrt_haproxyConsul']['extha_timeout_server_sec'],
       :public_cert => node['icrt_haproxyConsul']['public_cert'],
       :cacert => node['icrt_haproxyConsul']['cacert'],
       :cert => node['icrt_haproxyConsul']['cert'],
       :podname => node['icrt_haproxyConsul']['podname'],
       :service_prefix => "#{node['icrt_consulConfig']['service_prefix']}",
       :enable_accept_proxy => node['icrt_haproxyConsul']['enable_accept_proxy'],
       :enable_stats => node['icrt_haproxyConsul']['enable_stats']
      })
end

template "#{node['icrt_haproxyConsul']['haproxy_config_path']}/cors-origins.lst" do
  source 'cors-origins.erb'
  owner 'haproxy'
  group 'haproxy'
  mode 00744
  variables ({
       :cors_origin_list => node['icrt_haproxyConsul']['cors_origin_list']
      })
end


template "#{node['icrt_haproxyConsul']['haproxy_config_path']}/cors.lua" do
  source 'cors.erb'
  owner 'haproxy'
  group 'haproxy'
  mode 00744
end

cookbook_file "/etc/default/consul_template_haproxy" 

cookbook_file "/etc/systemd/system/haproxy-consul.service"

cookbook_file "/etc/ssl/infaca/#{node['icrt_haproxyConsul']['public_cert_file']}" do
  owner 'haproxy'
  group 'haproxy'
  mode '0440'
end


service 'rsyslog' do
  action [ :enable, :start ]
end

service 'haproxy-consul' do
  supports :status => true, :restart => true, :reload => true
  action [ :enable, :restart ]
end

service 'haproxy' do
  action [ :enable, :restart ]
end

