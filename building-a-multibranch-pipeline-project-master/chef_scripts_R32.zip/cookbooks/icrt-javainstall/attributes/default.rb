# This is a Chef attributes file. It can be used to specify default and override
# attributes to be applied to nodes that run this cookbook.

# Set a default name
default["icrt-javainstall"]["name"] = "Sam Doe"
default["icrt-javainstall"]["packageDir"] = "/opt/packages"
default["icrt-javainstall"]["jdkRPMname"] = "zulu8.36.0.1-ca-jdk8.0.202-linux.x86_64.rpm"
default["icrt-javainstall"]["javapath"] = "/usr/lib/jvm/zulu-8/bin"
default["icrt-javainstall"]["jrehome"] = "/usr/lib/jvm/zulu-8/"
default["icrt-javainstall"]["ZuluUrl"] = "https://artifacts.cloudtrust.rocks/icrt-generic/Utilities/zulu8.36.0.1-ca-jdk8.0.202-linux.x86_64.rpm"
default["icrt-javainstall"]["artifactory_auth_key"] = "AKCp5bBh9WHoRHb1D5htA6dGRAe8hUtfm4dt1dFVs8Ku1kmz9DQcTogaLAsSKHYukaHfZN7wf"