directory "packageDir" do
  path    node["icrt-javainstall"]["packageDir"]
	owner	"root"
	group	"root"
	mode	"0755"
end

artifactoryApiKey = node['icrt-javainstall']['artifactory_auth_key']

remote_file "#{node["icrt-javainstall"]["packageDir"]}/#{node["icrt-javainstall"]["jdkRPMname"]}" do
        source  node["icrt-javainstall"]["ZuluUrl"]
        owner    'root'
        group   'root'
        mode    "0755"
        headers 'X-JFrog-Art-Api' => artifactoryApiKey
        action :create
        not_if { ::File.exists?("#{node["icrt-javainstall"]["javapath"]}") }
end

rpm_package "#{node["icrt-javainstall"]["packageDir"]}/#{node["icrt-javainstall"]["jdkRPMname"]}" do
  action :install
  only_if { ::File.exist?("#{node["icrt-javainstall"]["packageDir"]}/#{node["icrt-javainstall"]["jdkRPMname"]}") }
end

file "#{node["icrt-javainstall"]["packageDir"]}/#{node["icrt-javainstall"]["jdkRPMname"]}" do
  action :delete
end
