resource_name :jre_install
property :version, String, required: true, default: '8u73-b02'
property :package_dir, String, default: '/opt/packages'
property :remote_path, String, default: 'http://download.oracle.com/otn-pub/java/jdk/'
property :rpm_name, String, default: 'jre-8u73-linux-x64.rpm'

def remote_url
  uri = ''
  uri << remote_path
  uri << '/' unless uri[-1] == '/'
  uri << "#{version}/#{rpm_name}"
  uri
end


action :install do
  log "Installing JRE" do
      level :info
  end

  directory "package_dir" do
    path  package_dir
  	owner	"root"
  	group	"root"
  	mode	"0755"
  end

  remote_file "#{package_dir}/#{rpm_name}" do
          source  "#{node.default["javainstall"]["oracledlUrl"]}"
          owner    'root'
          group   'root'
          mode    "0755"
          headers({ "Cookie" => "oraclelicense=accept-securebackup-cookie" })
          action :create_if_missing
          not_if { ::File.exist?("#{node.default["javainstall"]["javapath"]}") }
  end
  rpm_package "#{package_dir}/#{rpm_name}" do
    action :install
    only_if { ::File.exist?("#{package_dir}/#{rpm_name}") }
  end

  file "#{package_dir}/#{rpm_name}" do
    action :delete
  end
end
