#
# Cookbook Name:: icrt-rotateCatalinaOut
# Recipe:: default
#
# Copyright 2016, Informatica
#
# All rights reserved - Do Not Redistribute
#
cookbook_file "/etc/logrotate.d/tomcat" do
	source	"tomcat"
	mode	"0644"
	owner   "root"
	group   "root"
end

execute "enableScript" do
	command "logrotate -f /etc/logrotate.d/tomcat"
end