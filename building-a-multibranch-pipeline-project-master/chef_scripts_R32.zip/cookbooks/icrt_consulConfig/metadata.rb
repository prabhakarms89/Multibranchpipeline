name 'icrt_consulConfig'
maintainer 'The Authors'
maintainer_email 'you@example.com'
license 'all_rights'
description 'Installs/Configures icrt_consulConfig'
long_description 'Installs/Configures icrt_consulConfig'
version '0.3.1'

depends 'appintegration_service'
