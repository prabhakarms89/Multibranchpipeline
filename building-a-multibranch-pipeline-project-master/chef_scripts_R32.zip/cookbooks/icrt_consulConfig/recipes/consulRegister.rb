consul_service "#{node['icrt_consulConfig']['service_name']}" do  
  service_name "#{node['icrt_consulConfig']['service_name']}"  
  action :register
end

