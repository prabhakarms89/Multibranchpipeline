
consul_config "#{node['icrt_consulConfig']['service_name']}" do
  tomcat_install_path "#{node['appintegration_service']['tomcat_install_path']}"   
  server_port  "#{node['appintegration_service']['runtime_host_secure_port']}"
  service_name "#{node['icrt_consulConfig']['service_name']}"
  service_web_path "#{node['icrt_consulConfig']['service_external_web_path']}"
  enabledServiceRestartOnCrash  "#{node['icrt_consulConfig']['enabled_service_restart_on_crash']}"
  is_obm_node "#{node['icrt_consulConfig']['is_obm_node']}"
  is_interactive_node "#{node['icrt_consulConfig']['is_interactive_node']}"
  is_in_internal_haproxy  'true'
  is_in_external_haproxy  'true'
  is_in_idsma_haproxy  'false'  
  action :create
end

consul_health_check "#{node['icrt_consulConfig']['service_name']}" do
  service_name "#{node['icrt_consulConfig']['service_name']}"
  service_web_path "#{node['icrt_consulConfig']['service_healthcheck_web_path']}"
  healthcheck_url "#{node['icrt_consulConfig']['service_healthcheck_url']}"
  server_port  "#{node['appintegration_service']['runtime_host_secure_port']}"
  cacert  "#{node['appintegration_service']['cacert']}"
  cert  "#{node['appintegration_service']['cert']}"  
  action :create
end

