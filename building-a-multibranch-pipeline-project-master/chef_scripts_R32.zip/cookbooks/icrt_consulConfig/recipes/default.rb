#
# Cookbook Name:: icrt_consulConfig
# Recipe:: default
#
# Copyright (c) 2017 The Authors, All Rights Reserved.
