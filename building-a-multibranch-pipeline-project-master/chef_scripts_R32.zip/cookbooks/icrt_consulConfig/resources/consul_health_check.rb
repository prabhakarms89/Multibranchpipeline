#All tomcat related config
# server.xml
# setenv.sh
# TODO: ADD Server.xml ports connection ssl
# get the certification and load to cacert
# infa cert bundle

resource_name :consul_health_check
property :service_name, String, required: true
property :service_web_path, String, required: true
property :healthcheck_url, String, required: true, default: '/mgmtapi/healthy'
property :server_port, String, required: true
property :cacert, String, required: true
property :cert, String, required: true
property :host_name, String


action :create do

    directory "#{node['icrt_consulConfig']['consul_install_path']}/infa_conf" do
        owner 'root'
        group 'root'
        mode '0755'
        recursive true
        action :create
    end
    
    directory "#{node['icrt_consulConfig']['consul_install_path']}/bin" do
        owner 'root'
        group 'root'
        mode '0755'
        recursive true
        action :create
    end
     
    template "#{node['icrt_consulConfig']['consul_install_path']}/bin/#{service_name}_health_check.sh" do
         source 'check_service_health.erb'
         owner 'root'
         group 'root'
         mode '0755'
         cookbook 'icrt_consulConfig'
         variables ({
           :server_port => "#{server_port}",
           :service_web_path => "#{service_web_path}",
		   :healthcheck_url => "#{healthcheck_url}",
           :cacert => "#{cacert}",
           :cert => "#{cert}",
           :host_name => "#{node['fqdn']}"
         })
    action :create
    end

end

