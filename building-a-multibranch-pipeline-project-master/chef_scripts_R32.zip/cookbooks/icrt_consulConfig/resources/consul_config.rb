#All tomcat related config
# server.xml
# setenv.sh
# TODO: ADD Server.xml ports connection ssl
# get the certification and load to cacert
# infa cert bundle

resource_name :consul_config
property :tomcat_install_path, String 
property :service_name, String, required: true
property :service_web_path, String, required: true
property :server_port, String
property :host_name, String
property :podname, String, required: true, default: ''
property :enabledServiceRestartOnCrash, String, required: true, default: 'true'
property :tomcatPidPath, String, required: true, default: ''
property :is_in_internal_haproxy, String, required: true, default: 'false'
property :is_in_external_haproxy, String, required: true, default: 'false'
property :is_in_idsma_haproxy, String, required: true, default: 'false'
property :is_obm_node, String, required: true, default: 'false'
property :is_interactive_node, String, required: true, default: 'false'



action :create do

    directory "#{node['icrt_consulConfig']['consul_install_path']}/infa_conf" do
        owner 'root'
        group 'root'
        mode '0755'
        recursive true
        action :create
    end
    
    directory "#{node['icrt_consulConfig']['consul_install_path']}/bin" do
        owner 'root'
        group 'root'
        mode '0755'
        recursive true
        action :create
    end
  
    serviceTomcatPidPath = ( tomcatPidPath == '' ) ? "#{tomcat_install_path}/tomcat.pid" : "#{tomcatPidPath}"

    template "#{node['icrt_consulConfig']['consul_install_path']}/infa_conf/#{service_name}_chef_config.json" do
        source 'chef_config_json.erb'
        owner 'root'
        group 'root'
        mode '0444'
        cookbook 'icrt_consulConfig'
        variables ({
            :server_port => server_port,
            :consul_install_path => "#{node['icrt_consulConfig']['consul_install_path']}",            
            :service_name => "#{service_name}",
            :service_web_path => "#{service_web_path}",            
            :host_name => "#{node['hostname']}",
             # this is directly read from environmnet and not passed as argument by caller. 
            :podname => "#{node['icrt_consulConfig']['podname']}",
            :serviceTomcatPidPath => "#{serviceTomcatPidPath}",
            :enabledServiceRestartOnCrash => "#{enabledServiceRestartOnCrash}",
	    :service_prefix => "#{node['icrt_consulConfig']['service_prefix']}",
	    :health_check_timeout => "#{node['icrt_consulConfig']['health_check_timeout']}",
            :is_in_internal_haproxy => "#{is_in_internal_haproxy}",
            :is_in_external_haproxy => "#{is_in_external_haproxy}",
            :is_in_idsma_haproxy => "#{is_in_idsma_haproxy}",
            :is_obm_node => "#{node['icrt_consulConfig']['is_obm_node']}",
            :is_interactive_node => "#{node['icrt_consulConfig']['is_interactive_node']}"
        })
    action :create
    end
    
end

