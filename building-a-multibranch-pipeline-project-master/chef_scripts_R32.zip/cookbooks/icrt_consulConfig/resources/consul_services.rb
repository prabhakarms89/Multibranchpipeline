#
#Resource will start/stop/restart tomcat services
#
# We didn't do service because of provision deamon option didn't go well. We will need to fix it in the chef driver version

resource_name :consul_service
property :service_name, String, required: true
property :file, String

action :register do  
  http_request 'Register service at consul' do
     action :put
     url "#{node['icrt_consulConfig']['consul_base_url']}/v1/agent/service/register"
     file ::File.read("#{node['icrt_consulConfig']['consul_install_path']}/infa_conf/#{service_name}_chef_config.json")
     message("#{file}")
     headers 'Content-Type' => 'application/json'
  end

end

action :deregister do
  http_request 'Deregister service at consul' do
     action :put
     url "#{node['icrt_consulConfig']['consul_base_url']}/v1/agent/service/deregister/#{node['icrt_consulConfig']['service_prefix']}_#{service_name}_#{node['hostname']}"
  end

end
