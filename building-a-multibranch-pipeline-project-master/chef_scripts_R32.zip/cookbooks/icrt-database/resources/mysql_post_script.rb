resource_name :mysql_post_script

property :mysqlhost, String , required: true,default: '127.0.0.1'
property :mysqlport, String , required: true,default: '3306'
property :mysqluser, String , required: true,default: 'root'
property :mysqlpassword, String , required: true,default: 'change'
property :mysqlschema, String , required: true,default: 'test'
property :file_location, String, required: true, default: '/tmp/post_deploy.sql'
property :ssl_ca, String, default: ''
property :ssl_key, String, default: ''
property :ssl_cert, String, default: ''
property :cmdVerboseOpt, String, default: ''

action :run do
    execute "Run_SQL_Script" do
        ssl_args = ''
        if ssl_ca != ''
            ssl_args << " --ssl-ca=#{ssl_ca}"
        end
        if ssl_key != ''
            ssl_args << " --ssl-key=#{ssl_key}"
        end
        if ssl_cert != ''
            ssl_args << " --ssl-cert=#{ssl_cert}"
        end
        command "mysql -h #{mysqlhost} --port #{mysqlport} #{ssl_args} --user=#{mysqluser} --password=#{mysqlpassword} #{mysqlschema} #{cmdVerboseOpt} < #{file_location}"
    end
end
