resource_name :mysql_command

property :mysqluser, String , required: true,default: 'root'
property :mysqlpassword, String , required: true,default: 'change'
property :mysqlcommand, String, required: true, default: 'create schema notificationdb;'


action :run do
  file "/docker-entrypoint-initdb.d/create.sh" do
    content "mysql -u #{mysqluser} -p#{mysqlpassword} -e \'#{mysqlcommand}\'"
    mode '0755'
  end
end
