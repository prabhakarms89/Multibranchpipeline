resource_name :mysql_script

property :mysqlhost, String , required: true,default: '127.0.0.1'
property :mysqlport, String , required: true,default: '3306'
property :mysqluser, String , required: true,default: 'root'
property :mysqlpassword, String , required: true,default: 'change'
property :sql_content, String, required: true, default: 'create schema notificationdb;'
property :file_name, String, required: true, default: 'create.sql'
property :sslEnabled, String, default: 'false'
property :sslClientAuth, String, default: 'false'
property :spring_datasource_user, String, default: ''
property :spring_datasource_password, String, default: ''
property :db_schema, String, default: ''
property :ssl_ca, String, default: ''
property :ssl_key, String, default: ''
property :ssl_cert, String, default: ''
property :createSqlErbTemplate, String, default: 'create_sql.erb'

def sql_create_file
  create_file = ''
  # if node["virtualization"]["system"] == 'docker'
  #   create_file << "/docker-entrypoint-initdb.d/#{file_name}"
  # else
    create_file << "/tmp/#{file_name}"
  # end
end

action :run do
  template sql_create_file do
    source createSqlErbTemplate
    mode '0755'
    variables({
        :mysqlhost => mysqlhost,
        :mysqlport => mysqlport,
        :mysqluser => mysqluser,
        :mysqlpassword => mysqlpassword,
        :sslEnabled => sslEnabled,
        :sslClientAuth => sslClientAuth,
        :ssl_ca => ssl_ca,
        :ssl_key => ssl_key,
        :ssl_cert => ssl_cert,
        :db_schema => db_schema,
        :spring_datasource_user => spring_datasource_user,
        :spring_datasource_password => spring_datasource_password
    })
  end

  execute "Run_SQL_Script" do
      ssl_args = ''
      if ssl_ca != ''
          ssl_args << " --ssl-ca=#{ssl_ca}"
      end
      if ssl_key != ''
          ssl_args << " --ssl-key=#{ssl_key}"
      end
      if ssl_cert != ''
          ssl_args << " --ssl-cert=#{ssl_cert}"
      end
      command "mysql -h #{mysqlhost} --port #{mysqlport} #{ssl_args} --user=#{mysqluser} --password=#{mysqlpassword}  < /tmp/#{file_name}"
  end
end
