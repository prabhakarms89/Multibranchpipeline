# This is a Chef attributes file. It can be used to specify default and override
# attributes to be applied to nodes that run this cookbook.

# Set a default name
default["javainstall"]["name"] = "Sam Doe"
default["javainstall"]["jre_version"] = "jre1.8.0_161"
node.default["javainstall"]["packageDir"] = "/opt/packages"
node.default["javainstall"]["jdkRPMname"] = "jre-8u161-linux-x64.rpm"
node.default["javainstall"]["javapath"] = "/usr/java/jre1.8.0_161/bin/java"
node.default["javainstall"]["jrehome"] = "/usr/java/jre1.8.0_161/"
node.default["javainstall"]["oracledlUrl"] = "https://s3-us-west-2.amazonaws.com/ichs-build-artifacts/jre/8u73/#{node.default["javainstall"]["jdkRPMname"]}"
node.default["javainstall"]["jcepolicy"] = "https://artifacts.cloudtrust.rocks/iics-generic/thirdparty/jre-extras/jcepolicy/8.0/"
node.default["javainstall"]["jre_artifactory_url"] = "https://infacloud.jfrog.io/infacloud/iics-generic/thirdparty/jre/8u161/jre-8u161-linux-x64.rpm"

node.default["javainstall"]["jdkTarname"] = "zulu8.33.0.1-jdk8.0.192-linux_x64.tar.gz"
node.default["javainstall"]["javaInstallPath"] = "/opt/java/"
node.default["javainstall"]["javapath"] = "/opt/java/zulu8.33.0.1-jdk8.0.192-linux_x64/bin/java"
node.default["javainstall"]["jdkhome"] = "/opt/java/zulu8.33.0.1-jdk8.0.192-linux_x64/"
node.default["javainstall"]["openJdkUrl"] = "https://artifacts.cloudtrust.rocks/iics-generic/OpenJDK/jdk8/#{node.default["javainstall"]["jdkTarname"]}"
node.default["javainstall"]["jfrogAuthHeader"] = node["global_infa_properties"]["artifactory_key"]

default["javainstall"]["artifactory_key"] = node["global_infa_properties"]["artifactory_key"]

default["javainstall"]["remote_file_backup"] = node["global_infa_properties"]["remote_file_backup"]
# For further information, see the Chef documentation (https://docs.chef.io/essentials_cookbook_attribute_files.html).
