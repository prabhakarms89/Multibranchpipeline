# This is a Chef recipe file. It can be used to specify resources which will
# apply configuration to a server.
# Default recipe doesn't do anything all are defined as

log "Default recipe. All actions are defined in resources" do
  level :info
end

# For more information, see the documentation: https://docs.chef.io/essentials_cookbook_recipes.html
