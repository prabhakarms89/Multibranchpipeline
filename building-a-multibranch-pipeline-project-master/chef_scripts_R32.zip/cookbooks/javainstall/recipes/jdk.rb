
jdk_install "Install Jdk" do
    artifactory_key node["javainstall"]['artifactory_key']
    action:install
end
