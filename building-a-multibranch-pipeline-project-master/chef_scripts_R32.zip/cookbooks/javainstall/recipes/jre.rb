jre_install "Install JRE" do
    artifactory_key node["javainstall"]['artifactory_key']
    version "#{node['javainstall']['jre_version']}"
    action:install
end
