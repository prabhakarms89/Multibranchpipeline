name 'javainstall'
maintainer 'The Authors'
maintainer_email 'you@example.com'
license 'all_rights'
description 'Installs/Configures java'
long_description 'Installs/Configures java'
version '1000.1.14'

depends 'infa-properties'
