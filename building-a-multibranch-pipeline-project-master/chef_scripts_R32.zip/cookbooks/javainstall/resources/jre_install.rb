resource_name :jre_install
property :version, String, required: true, default: '8u161'
property :package_dir, String, default: '/opt/packages'
property :remote_path, String, default: 'notinuse'
property :rpm_name, String, default: 'jre-8u161-linux-x64.rpm'
property :update_jce, String, default: 'false'
property :artifactory_key, String, default: "#{node["javainstall"]["artifactory_key"]}"


action :install do
  log "Installing JRE" do
      level :info
  end

  directory "package_dir" do
    path  package_dir
  	owner	"root"
  	group	"root"
  	mode	"0755"
  end

  remote_file "#{package_dir}/#{rpm_name}" do
    source  "#{node.default["javainstall"]["jre_artifactory_url"]}"
    owner    'root'
    group   'root'
    mode    "0755"
    headers({ "X-JFrog-Art-Api" => "#{artifactory_key}" })
    backup node.default["javainstall"]["remote_file_backup"]
    not_if { ::File.exist?("#{node.default["javainstall"]["javapath"]}") }
  end


  rpm_package "#{package_dir}/#{rpm_name}" do
    action :install
    only_if { ::File.exist?("#{package_dir}/#{rpm_name}") }
  end

  file "#{package_dir}/#{rpm_name}" do
    backup false
    action :delete
  end
  if "#{update_jce}" == 'true'
	  remote_file "#{node.default["javainstall"]["jrehome"]}lib/security/US_export_policy.jar" do
      source  "#{node.default["javainstall"]["jcepolicy"]}US_export_policy.jar"
      owner    'root'
      group   'root'
      mode    "0755"
      headers({ "X-JFrog-Art-Api" => "#{artifactory_key}" })
      backup node.default["javainstall"]["remote_file_backup"]
      action :create
	  end

    remote_file "#{node.default["javainstall"]["jrehome"]}lib/security/local_policy.jar" do
      source  "#{node.default["javainstall"]["jcepolicy"]}local_policy.jar"
      owner    'root'
      group   'root'
      mode    "0755"
      headers({ "X-JFrog-Art-Api" => "#{artifactory_key}" })
      backup node.default["javainstall"]["remote_file_backup"]
      action :create
    end
  end
end
