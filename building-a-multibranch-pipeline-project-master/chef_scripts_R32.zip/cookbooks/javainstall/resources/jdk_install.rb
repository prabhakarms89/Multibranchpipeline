resource_name :jdk_install
property :update_jce, String, default: 'false'
property :artifactory_key, String, default: "#{node["javainstall"]["artifactory_key"]}"


action :install do

  directory "packageDir" do
    path    node.default["javainstall"]["packageDir"]
    owner "root"
    group "root"
    mode  "0755"
  end

  remote_file "#{node.default["javainstall"]["packageDir"]}/jdk.tar.gz" do
    source  node.default["javainstall"]["openJdkUrl"]
    owner    'root'
    group   'root'
    mode    "0755"
    headers({ "X-JFrog-Art-Api" => "#{artifactory_key}" })
    action :create
    not_if { ::File.exists?("#{node.default["javainstall"]["javapath"]}") }
  end

  directory "#{node.default["javainstall"]["javaInstallPath"]}" do
    owner 'root'
    group 'root'
    mode '0755'
    recursive true
    action :create
  end

  script 'Extract Jdk' do
    interpreter "bash"
    code <<-EOH         
    echo "Extracting JDK..."
       tar -xf #{node.default["javainstall"]["packageDir"]}/jdk.tar.gz --directory #{node.default["javainstall"]["javaInstallPath"]}
       EOH
    only_if { ::File.exist?("#{node.default["javainstall"]["packageDir"]}/jdk.tar.gz") }   
  end

  file "#{node.default["javainstall"]["packageDir"]}/jdk.tar.gz" do
    action :delete
  end

  if "#{update_jce}" == 'true'
      remote_file "#{node.default["javainstall"]["jdkhome"]}jre/lib/security/US_export_policy.jar" do
         source  "#{node.default["javainstall"]["jcepolicy"]}US_export_policy.jar"
         owner    'root'
         group   'root'
         mode    "0755"
         headers({ "X-JFrog-Art-Api" => "#{artifactory_key}" })
         action :create
      end

      remote_file "#{node.default["javainstall"]["jdkhome"]}jre/lib/security/local_policy.jar" do
         source  "#{node.default["javainstall"]["jcepolicy"]}local_policy.jar"
         owner    'root'
         group   'root'
         mode    "0755"
         headers({ "X-JFrog-Art-Api" => "#{artifactory_key}" })
         action :create
      end
  end
end