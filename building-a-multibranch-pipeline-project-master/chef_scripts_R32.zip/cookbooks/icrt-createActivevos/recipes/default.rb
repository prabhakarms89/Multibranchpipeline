#
# Cookbook Name:: icrt-createActivevos
# Recipe:: default
#
# Copyright 2017, Informatica
#
# All rights reserved - Do Not Redistribute
#

# FIXME: This recipe creates a volume, we are assuming it is an EBS volume. We will need
# to snapshot that volume at the end of AMI Bake and ensure that this snapshot is launched
# and mounted at the correct point on instance restart or the instance will not boot.

vosBaseDir = '/activevos'
vosAppDir = "#{vosBaseDir}/app"
vosVarDir = '/var/activevos'
mountDevice = '/dev/xvdc'

[ vosBaseDir, vosAppDir ].each do |curDir| 
  directory curDir do
	mode	'0755'
	owner	'icrt-user'
	group	'icrt-user'
  end
end

# Link our app install dir to the expected install point
link vosVarDir do
  to vosAppDir
end

# Only format and mount this device if configured to do so
if node['icrt-createActivevos']['mountedVosDirectory']
  execute "make_fs" do
	 command	"mkfs -t ext4 #{mountDevice}"
	 user		"root"
	 group		"root"
	 not_if		"grep '#{mountDevice}' /etc/fstab"
  end
 
  execute "modify_fstab_activevos" do
	 command	"echo '#{mountDevice} #{vosBaseDir} ext4    defaults,nodev  0 0' >> /etc/fstab"
	 user		"root"
	 group		"root"
	 not_if		"grep '#{mountDevice}' /etc/fstab"
  end
 
  execute "mount_activevos" do
	 command	"mount #{mountDevice}"
	 user		"root"
	 group		"root"
  end
end