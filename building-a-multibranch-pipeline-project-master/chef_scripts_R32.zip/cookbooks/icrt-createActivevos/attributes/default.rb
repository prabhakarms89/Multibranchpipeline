# Whether or not we should attach a device at the activeVOS directory location 
node.default['icrt-createActivevos']['mountedVosDirectory'] = true