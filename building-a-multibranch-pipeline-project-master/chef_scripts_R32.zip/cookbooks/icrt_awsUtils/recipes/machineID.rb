# Write this script out to cron.hourly so it runs automatically every hour
cronTargetFile = '/etc/cron.hourly/retrieve-ae-machine-id-from-ec2-tag.sh'

cookbook_file cronTargetFile do
  source "retrieve-ae-machine-id-from-ec2-tag.sh"
  mode 00755
end

# This cron job already runs hourly, so just add an entry to fire it on reboot.
# We want fresh tag data on every instance restart since that's a very likely
# time for this to change
cron 'update /etc/profile.d/instancetags.sh on restart' do
  command "#{cronTargetFile} >> /var/log/cron.icrt.profile-tag-updater.out  2>> /var/log/cron.icrt.profile-tag-updater.err"
  time :reboot
end