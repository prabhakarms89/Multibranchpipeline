#!/bin/bash

# exit on error
set -eu -o pipefail

# This script is run frequently by cron, so we want to keep it relatively quiet so we don't fill up the logs with unnecessary output

# This is the EC2 tagname to look for
TAG_NAME="AE_MACHINE_ID"

# This is the file we will eventually write this value to
TARGET_FILE="/etc/profile.d/instancetags.sh"

# This is the environment variable to write out to the target file
TAG_VAR_NAME="TAG_${TAG_NAME}"

if [ -f /sys/hypervisor/uuid ] && [ `head -c 3 /sys/hypervisor/uuid` == ec2 ]; then

	# Grab this instance's ID from the API
	INSTANCE_ID="`wget -qO- http://169.254.169.254/latest/meta-data/instance-id`"

	# The availability zone is the region plus a letter, e.g. us-west-2b - trim the letter off to get the region (us-west-2)
	REGION="`wget -qO- http://169.254.169.254/latest/meta-data/placement/availability-zone | sed -e 's:\([0-9][0-9]*\)[a-z]*\$:\\1:'`"

	# To get the value of this tag, retrieve the EC2 tag data for this tag:
	#
	# TAGS	AE_MACHINE_ID	i-0d6734b3c7700f2da	instance	sample-ae-machine-id
	#
	# and only keep the 5th column:
	#
	# sample-ae-machine-id
	#
	TAG_VALUE="`aws ec2 describe-tags --filters "Name=resource-id,Values=$INSTANCE_ID" "Name=key,Values=$TAG_NAME" --region $REGION --output=text | cut -f5`"

	# This is the value to search TARGET_FILE for to determine whether this is an add or an update
	TAG_SEARCH_PATTERN="^export ${TAG_VAR_NAME}=.*"

 	# This is the actual line to write out to TARGET_FILE
	TARGET_EXPORT_LINE="export $TAG_VAR_NAME='${TAG_VALUE}'"

	if [[ -f $TARGET_FILE && $(grep -c "$TAG_SEARCH_PATTERN" $TARGET_FILE) -eq 1 ]]; then

		# If we're here, TARGET_FILE exists and has this tag in it - determine if we're updating it or not
		if  [[ $(grep -c "^$TARGET_EXPORT_LINE" $TARGET_FILE) -ne 1 ]]; then

			# If we're here, then TARGET_FILE's tag is different than what we want to set - update it now
			echo "Updating the tag $TAG_NAME to $TAG_VALUE in $TARGET_FILE"
			sed -i -e "s/$TAG_SEARCH_PATTERN/$TARGET_EXPORT_LINE/g" $TARGET_FILE
		fi
	else

		# If we're here, TARGET_FILE either didn't exist or didn't have this tag in it - append it now 
		echo "Adding the tag [$TAG_NAME] with value [$TAG_VALUE] to [$TARGET_FILE] (as: [$TARGET_EXPORT_LINE]) - it was not present"
		echo "export $TAG_VAR_NAME='${TAG_VALUE}'" >> $TARGET_FILE
	fi
else

	# This is not an EC2 machine - do nothing
	echo 1>&2 "Value for EC2 instance tag [$TAG_NAME] not retrieved - script is not running inside of EC2!"
	exit 1
fi