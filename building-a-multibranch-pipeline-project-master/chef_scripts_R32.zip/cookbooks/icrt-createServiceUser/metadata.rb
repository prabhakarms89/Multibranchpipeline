name             'icrt-createServiceUser'
maintainer       'Informatica'
maintainer_email 'YOUR_EMAIL'
license          'All rights reserved'
description      'Creates service user for tomat startup'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.1.0'
