#
# Cookbook Name:: icrt-createServiceUser
# Recipe:: default
#
# Copyright 2017, Informatica
#
# All rights reserved - Do Not Redistribute
#

group "tomcat" do
    action :create
end

 user "tomcat" do
    gid "tomcat"
	comment 'tomcat application user'
	action :create
 end
 
execute "set service user expiry" do
	 command	"chage -I -1 -m 0 -M -1 -E -1 tomcat"
end
 

# Add consul user in sudoers
if File.file?('/etc/sudoers')
  execute "consul sudo access" do
        command         "sudo bash -c \"echo 'consul          ALL=(ALL)       NOPASSWD: ALL'\" >> /etc/sudoers"
        user            "root"
        group           "root"
        not_if          "grep 'consul          ALL=(ALL)       NOPASSWD: ALL' /etc/sudoers"
  end
end