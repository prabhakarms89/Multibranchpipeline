icrt-appFileLimits Cookbook
===========================
This cookbook reconfigures system-level per-user open-file limits by replacing `/etc/security/limits.conf` with an updated version 

Usage
-----
#### icrt-appFileLimits::default
TODO: Write usage instructions for each cookbook.

e.g.
Just include `icrt-appFileLimits` in your node's `run_list`:

```json
{
  "name":"my_node",
  "run_list": [
    "recipe[icrt-appFileLimits]"
  ]
}
```