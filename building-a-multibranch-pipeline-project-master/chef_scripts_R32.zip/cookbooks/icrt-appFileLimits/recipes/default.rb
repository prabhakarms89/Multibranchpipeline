#
# Cookbook Name:: icrt-appFileLimits
# Recipe:: default
#
# Copyright 2015, Informatica
#
# All rights reserved - Do Not Redistribute

cookbook_file '/etc/security/limits.conf' do
	source		'limits.conf'
	owner		'root'
	group		'root'
	mode		'0755'
end