#
# Cookbook Name:: deploy-services

resource_name :war_deploy

property :version, String , required: true,default: 'latest'
property :war_name, String, required: true, default: 'notification-service.war'
property :artifact_store, String, required: true, default: 'jenkins'
property :remote_base, String, required: true, default: 'http://icsbld:8080/view/Services/job/notificationsvc'
property :dest_path, String, required:true, default: '/opt/tomcat/webapps'
property :artifact_path, String,default: "/opt/artifacts"


def remote_url
  if artifact_store == 'jenkins'
      remote_url="#{remote_base}"
      # TODO: We will need to make this more dynamic to have resource find right artifact location. this elsif may not require but it
      # should reminder that we treat this.
  elsif artifact_store  == 'local'
      remote_url="#{remote_base}"
  end
end

def remote_uri
    uri = ''
    uri << remote_url
    uri << '/' unless uri[-1] == '/'
    uri << "#{war_name}"
    uri
  end
=begin
def containerid
   command

end
=end
action :install do
    remote_file "#{war_name}" do
      source "#{remote_uri}"
      path "#{dest_path}/#{war_name}"
      owner "tomcat"
      group "tomcat"
      mode "0755"
      action :create
    end
end
