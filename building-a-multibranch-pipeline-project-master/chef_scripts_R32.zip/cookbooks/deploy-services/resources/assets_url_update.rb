resource_name :assets_url_update

property :file_pattern, String, name_property: true
property :url, String
property :context_path, String, required: false, default: ""

action :assets_url_update do
  ruby_block "updateResourceUrl" do
    block do
      unless url.nil? or url.empty?
        Dir.glob(file_pattern) do |html_file|
          file = Chef::Util::FileEdit.new(html_file)

          ## Update links to static resources

          context_url = (context_path.nil? or context_path.empty?) ? url : "#{url}#{context_path}/"

          # Match script and link resources which do not start with http
          # If resource has relative path prefix (../), it will be ignored
          file.search_file_replace(/<script(.*?)src="(?!(http|\/))(\.\.\/)*(.*?)"/, %{<script\\1src="#{context_url}\\4"})
          file.search_file_replace(/<link(.*?)href="(?!(http|\/))(\.\.\/)*(.*?)"/, %{<link\\1href="#{context_url}\\4"})

          # For absolute path references, don't append context_path
          # So /absolute/path/file.css will be rendered as https://cdn.url/absolute/path/file.css
          # But don't replace for //cdn.url/ links
          file.search_file_replace(/<script(.*?)src="(?!http|\/\/)\/(.*?)"/, %{<script\\1src="#{url}\\2"})
          file.search_file_replace(/<link(.*?)href="(?!http|\/\/)\/(.*?)"/, %{<link\\1href="#{url}\\2"})

          ## Update locations for symphonyResourcePath, shellPath, icsAppPath, cmdPath
          ## E.g. from index.html: window.symphonyResourcePath = '../../symphony';
          ## Should becode: window.symphonyResourcePath = 'https://cdn.url/cloudUI/symphony';

          # Match paths which do not start with http
          # If resource has relative path prefix (../), it will be ignored

          file.search_file_replace(/(symphonyResourcePath|shellPath|icsAppPath|cmdPath|shellResourcesPath)\s*=\s*['"](?!(http|\/))(\.\.\/)*(.*?)['"]/,
                                    %{\\1 = '#{context_url}\\4'})

          ## Update locale locations. References are passed to lcoale library in couple of ways:
          #
          ## Option 1. As objects with path property:
          # bundlesRootPathsArray: [{
          #   path: '../../app/cmd/locale/cmdx_x_x',
          #   enableBackwardsCompatibility: true
          #  }, {
          #   path: '../../app/ics/locale/icsx_x_x'
          # }]
          #
          ## Option 2. As array of paths:
          # bundlesRootPathsArray: [ '../../app/ics/locale/icsx_x_x' ]

          # Match paths which do not start with http
          # If resource has relative path prefix (../), it will be ignored

          # For this one, simplification is done, we assume there will be word 'locale' in the path.

          file.search_file_replace(/path\s*:\s*['"](?!(http|\/))(\.\.\/)*(.*?locale.*?)['"]/,
                                    %{path: '#{context_url}\\3'})

          # This one will only update only first element in the array. Works for ICS.

          file.search_file_replace(/bundlesRootPathsArray\s*:\s*\[\s*['"](?!(http|\/))(\.\.\/)*(.*?)['"]\s*\]/,
                                    %{bundlesRootPathsArray: \['#{context_url}\\3'\]})

          file.write_file
        end
      end
    end
  end
end


=begin Example

assets_url_update "#{tomcat_path}/webapps/#{service}/**/*.html" do
  url 'https://cdnUrl'
  context_path my-service
end

Empty url will be skipped

=end
