#
# Cookbook Name:: icrt-sshUserMgr
# Recipe:: default
#
# Copyright 2015, Informatica
#
# All rights reserved - Do Not Redistribute

# FIXME: move authKeys to consul
# FIXME Only change passwd post-config

icrtUser = 'icrt-user'
icrtGroup = 'icrt-user'

group icrtGroup do
  action :create
end

user icrtUser do
	group	icrtGroup
	password	node['icrt-sshUserMgr']['hashPassword']
	home	"/home/#{icrtUser}"
	manage_home true
	not_if	"grep #{icrtUser} /etc/passwd"
end

directory "/home/#{icrtUser}" do
	mode	'0755'
	owner	icrtUser
	group	icrtGroup
end

directory "/home/#{icrtUser}/.ssh" do
	mode	'0700'
	owner	icrtUser
	group	icrtGroup
end

cookbook_file "/home/#{icrtUser}/.ssh/authorized_keys" do
	source	node['icrt-sshUserMgr']['authorizedKeysSource']
	owner	icrtUser
	group	icrtGroup
	mode	'0400'
end

execute "modifyssh_user" do
	command	"sudo  sed -i '/AllowGroups/s/\$/ #{icrtUser}/' /etc/ssh/sshd_config"
	not_if	"grep AllowGroups /etc/ssh/sshd_config | grep #{icrtUser}"
end

execute "icrtUserAccess" do
	command		"sudo bash -c \"echo 'icrt-user ALL=(ALL)NOPASSWD: ALL'\" >> /etc/sudoers"
	user		"root"
	group		"root"
	not_if		"grep 'icrt-user ALL=(ALL)NOPASSWD: ALL' /etc/sudoers"
end

cookbook_file "/home/#{icrtUser}/.bash_profile" do
	source	".bash_profile"
	owner	icrtUser
	group	icrtGroup
	mode	'0644'
end

cookbook_file "/home/#{icrtUser}/.bashrc" do
	source	".bashrc"
	owner	icrtUser
	group	icrtGroup
	mode	'0644'
end

cookbook_file "/root/.bashrc" do
	source	".bashrc"
	owner	'root'
	group	'root'
	mode	'0644'
end

execute "set #{icrtUser} user expiry" do
	 command	"chage -I -1 -m 0 -M -1 -E -1 #{icrtUser}"
end

service "sshd" do
	action	:restart
end