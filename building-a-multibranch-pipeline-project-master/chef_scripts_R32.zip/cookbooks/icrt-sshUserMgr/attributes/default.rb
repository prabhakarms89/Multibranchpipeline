node.default['icrt-sshUserMgr']['plainTextPassword'] = '8QRq~6HAbEr9T->+'
node.default['icrt-sshUserMgr']['hashPassword'] = `openssl passwd -1 "#{ node.default['changePassword']['plainTextPassword'] }"`

node.default['icrt-sshUserMgr']['hashPassword'] = "#{ node.default['icrt-sshUserMgr']['hashPassword'] }".gsub(/\n/, "")

# Which of the source files to use for the SSH authorized keys for this instance - options are:
# * icrtKey.pub
# * ICRTNP-06012017.pub
# * icrtKey2.pub
node.default['icrt-sshUserMgr']['authorizedKeysSource'] = "icrtKey2.pub"